# CellWeave Contracts (`cellweave-contracts`)

The single cross-language source of truth for CellWeave API contracts, JSON Schemas, event schemas, Run Manifests, Artifact Manifests, TypeScript types, and Python Pydantic models.

## Repository Responsibilities

Per the [CellWeave Production Master System Design v1.0](docs/architecture/CellWeave-Production-Master-System-Design-v1.0.pdf) and [AGENTS.md](AGENTS.md):
- **Authoritative Contract Formats**: OpenAPI 3.1 and JSON Schema (Draft 2020-12).
- **Generated Outputs**: Strict TypeScript types (`@cellweave/contracts`) and Python Pydantic v2 models (`cellweave_contracts`).
- **No Hand-Written Payloads**: No consuming repository (`cellweave-web`, `cellweave-orchestrator`, `cellweave-science`) may maintain duplicated handwritten payload interfaces for cross-boundary messages.
- **Immutable Provenance**: Run Manifest and Artifact Manifest schemas preserve strict reproducibility semantics.

## Directory Structure

```
├── .github/workflows/ci.yml       # Automated CI validation & drift check
├── docs/
│   ├── adr/                       # Architectural Decision Records (ADRs)
│   └── architecture/              # Master system design & operational mirrors
├── openapi/
│   └── v1/openapi.yaml            # OpenAPI 3.1 REST API specification
├── schemas/
│   ├── compute/                   # Compute provider contracts (submit, status, etc.)
│   ├── domain/                    # Domain state enums (RunState, UploadState, etc.) & DomainError
│   ├── events/                    # Event schemas (usage-event, audit-event, polar-webhook)
│   ├── jobs/                      # Scientific job payload envelopes (14 logical steps)
│   └── manifests/                 # RunManifest and ArtifactManifest schemas
├── generated/
│   ├── ts/                        # Generated TypeScript types & branded IDs
│   └── python/cellweave_contracts/# Generated Python Pydantic v2 models
├── scripts/
│   ├── generate.mjs               # Deterministic dual-target code generator
│   └── validate-schemas.mjs       # Ajv schema validator
├── tests/
│   ├── fixtures/valid/            # Golden valid payload fixtures
│   ├── fixtures/invalid/          # Rejected invalid payload fixtures
│   └── python/                    # Python pytest model verification
├── package.json                   # TypeScript contracts package definition
├── pyproject.toml                 # Python contracts package definition
└── tsconfig.json                  # Strict TypeScript compiler options
```

## Available Scripts

```bash
# Validate all JSON schemas and OpenAPI 3.1 specs
pnpm validate

# Generate TypeScript types and Python Pydantic models
pnpm generate

# Run TypeScript typechecker
pnpm typecheck

# Run contract & fixture test suites
pnpm test

# Build distributable TypeScript package
pnpm build
```

## Versioning & Compatibility Rules

1. **Public APIs**: Breaking changes require `/v2`.
2. **Internal Contracts**: Internal schemas use explicit `schemaVersion`.
3. **Scientific Job Payloads**: Always carry both `schemaVersion` and `pipelineVersion`.
4. **CI Drift Detection**: CI fails if committed generated files diverge from schemas (`git diff --exit-code`).

## Generic Matrix Identity Mapping (`MetadataMappingSubmission`)

`MetadataMappingSubmission` (`schemas/domain/metadata-mapping-submission.v1.json`) separates four distinct identity concepts for `GENERIC_MATRIX` imports while preserving backward compatibility for `H5AD`, `TENX_H5`, and `TENX_MTX`:

1. **Source Matrix Identity** (CSV/TSV row-axis columns):
   - `matrixCellIdColumn`: Explicit column in a CSV/TSV `MATRIX` file containing source cell-axis identifiers when cells are represented by matrix rows (`CELLS_BY_GENES`). Column-axis feature identifiers come from the non-cell header columns.
   - `matrixFeatureIdColumn`: Explicit column in a CSV/TSV `MATRIX` file containing source feature-axis identifiers when features are represented by matrix rows (`GENES_BY_CELLS`). Column-axis cell identifiers come from the non-feature header columns.
2. **Metadata Join Identity** (metadata table keys matched against source matrix tokens):
   - `cellMetadataJoinColumn`: Column in `CELL_METADATA` containing source cell tokens used to join metadata rows to matrix cell identity.
   - `featureMetadataJoinColumn`: Column in `FEATURE_METADATA` containing source feature tokens used to join metadata rows to matrix feature identity (`source_feature_id`).
3. **Canonical Identity** (authoritative canonical AnnData `obs_names`, `var_names`, and symbols):
   - `cellIdColumn`: Authoritative canonical cell identifier column in supplied `CELL_METADATA` (may equal `cellMetadataJoinColumn` or translate source tokens into canonical cell IDs; never implies sample identity).
   - `geneIdColumn`: Canonical/stable feature identifier column used for canonical `var_names` when `FEATURE_METADATA` supplies it (distinct from `featureMetadataJoinColumn`).
   - `geneSymbolColumn`: Descriptive gene symbol column only (`var["gene_symbol"]`).
4. **Generic MTX Axis-Index Identity** (coordinate-matrix row/column association):
   - `cellAxisIndexColumn`: Column in `CELL_METADATA` containing the explicit 1-based integer Generic MTX cell-axis coordinate (`1..n_cells`).
   - `featureAxisIndexColumn`: Column in `FEATURE_METADATA` containing the explicit 1-based integer Generic MTX feature-axis coordinate (`1..n_features`).
   - **MTX Orientation Interaction**:
     - Under `orientation = "CELLS_BY_GENES"`, MTX row coordinate (`1..n_rows`) maps to the cell axis (`cellAxisIndexColumn`) and MTX column coordinate (`1..n_cols`) maps to the feature axis (`featureAxisIndexColumn`).
     - Under `orientation = "GENES_BY_CELLS"`, MTX row coordinate (`1..n_rows`) maps to the feature axis (`featureAxisIndexColumn`) and MTX column coordinate (`1..n_cols`) maps to the cell axis (`cellAxisIndexColumn`).
   - Metadata file row order is never treated as implicit coordinate authority; rows are aligned strictly by explicit 1-based axis indices (`1..N` permutation).

## Canonical Artifact Publication Capabilities (`CanonicalArtifactPublicationCapabilities` & `CanonicalArtifactPublicationResult`)

Canonical artifact publication (`schemas/jobs/canonical-artifact-publication-capabilities.v1.json` and `schemas/jobs/canonical-artifact-publication-result.v1.json`) enforces strict **capability-based least privilege** across the control-plane and scientific-compute boundaries:

1. **Internal Trusted Control-Plane Authority Only (Never Browser Input)**:
   - `CanonicalArtifactPublicationCapabilities` and `CanonicalArtifactPublicationResult` are internal worker/control-plane contracts.
   - They are **never** accepted from browser or public client requests. A browser client must never submit `putUrl`, `getUrl`, or signed headers.
2. **End-to-End Responsibility Boundary**:
   - **Trusted Web / Control Plane**:
     - Owns `organizationId`, `projectId`, `datasetVersionId`, bucket configuration, and R2 credentials.
     - Derives the deterministic canonical object key (`org/{organizationId}/project/{projectId}/datasets/{datasetVersionId}/canonical/canonical.h5ad`).
     - Presigns a short-lived conditional `PUT` capability (`putUrl` + `requiredPutHeaders` with `"If-None-Match": "*"`) and a short-lived `GET` capability (`getUrl` + `requiredGetHeaders`) scoped exclusively to that single canonical object.
   - **Scientific Compute (`cellweave-science`)**:
     - **Never constructs canonical R2 keys** and never receives `R2_ACCESS_KEY_ID`, `R2_SECRET_ACCESS_KEY`, bucket names, `organizationId`, `projectId`, or arbitrary destination keys.
     - Validates the local `canonical.h5ad`, computes the exact streaming SHA-256 and byte size over local bytes, executes the conditional `PUT` capability (or reconciles an existing object via the `GET` capability), streams remote bytes via `getUrl` to verify exact byte size and SHA-256 (never trusting HTTP `ETag` as a scientific checksum), and returns `CanonicalArtifactPublicationResult` (`status: "PUBLISHED" | "ALREADY_PRESENT"`).
     - Fails controlled if `expiresAt` (explicit UTC timestamp) has passed; never auto-refreshes credentials.
     - Treats integrity/content conflicts as hard errors rather than returning a success status.
   - **Downstream Database Finalization**:
     - Independently re-derives the canonical artifact key server-side and atomically finalizes the dataset version import. Never trusts a caller-supplied `canonicalArtifactKey`.
3. **Ephemeral Capability Redaction**:
   - `putUrl` and `getUrl` carry embedded presigned query signatures and must be treated as ephemeral secrets. Consuming services must redact query strings/signatures from all structured logs, exception messages, and diagnostics.

## Phase 4 execution contracts

Canonical JSON Schemas define execution envelopes, ceilings, scoped capabilities, projections, control and results. Generated run/step transitions and service environment/scope vocabulary are shared across services. Service keys and raw JWTs are never contract fields. Resource maxComputeUnits is an integer CPU-second ceiling, not a billing credit.
