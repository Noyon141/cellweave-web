# CellWeave Contracts (`cellweave-contracts`)

The single cross-language source of truth for CellWeave API contracts, JSON Schemas, event schemas, Run Manifests, Artifact Manifests, TypeScript types, and Python Pydantic models.

## Repository Responsibilities

Per the [CellWeave Production Master System Design v1.0](docs/architecture/CellWeave-Production-Master-System-Design-v1.0.pdf) and [AGENTS.md](AGENTS.md):
- **Authoritative Contract Formats**: OpenAPI 3.1 and JSON Schema (Draft 2020-12).
- **Generated Outputs**: Strict TypeScript types (`@cellweave/contracts`) and Python Pydantic v2 models (`cellweave_contracts`).
- **No Hand-Written Payloads**: No consuming repository (`cellweave-web`, `cellweave-orchestrator`, `cellweave-science`) may maintain duplicated handwritten payload interfaces for cross-boundary messages.
- **Immutable Provenance**: Run Manifest and Artifact Manifest schemas preserve strict reproducibility semantics.

## Directory Structure

```
├── .github/workflows/ci.yml       # Automated CI validation & drift check
├── docs/
│   ├── adr/                       # Architectural Decision Records (ADRs)
│   └── architecture/              # Master system design & operational mirrors
├── openapi/
│   └── v1/openapi.yaml            # OpenAPI 3.1 REST API specification
├── schemas/
│   ├── compute/                   # Compute provider contracts (submit, status, etc.)
│   ├── domain/                    # Domain state enums (RunState, UploadState, etc.) & DomainError
│   ├── events/                    # Event schemas (usage-event, audit-event, polar-webhook)
│   ├── jobs/                      # Scientific job payload envelopes (14 logical steps)
│   └── manifests/                 # RunManifest and ArtifactManifest schemas
├── generated/
│   ├── ts/                        # Generated TypeScript types & branded IDs
│   └── python/cellweave_contracts/# Generated Python Pydantic v2 models
├── scripts/
│   ├── generate.mjs               # Deterministic dual-target code generator
│   └── validate-schemas.mjs       # Ajv schema validator
├── tests/
│   ├── fixtures/valid/            # Golden valid payload fixtures
│   ├── fixtures/invalid/          # Rejected invalid payload fixtures
│   └── python/                    # Python pytest model verification
├── package.json                   # TypeScript contracts package definition
├── pyproject.toml                 # Python contracts package definition
└── tsconfig.json                  # Strict TypeScript compiler options
```

## Available Scripts

```bash
# Validate all JSON schemas and OpenAPI 3.1 specs
pnpm validate

# Generate TypeScript types and Python Pydantic models
pnpm generate

# Run TypeScript typechecker
pnpm typecheck

# Run contract & fixture test suites
pnpm test

# Build distributable TypeScript package
pnpm build
```

## Versioning & Compatibility Rules

1. **Public APIs**: Breaking changes require `/v2`.
2. **Internal Contracts**: Internal schemas use explicit `schemaVersion`.
3. **Scientific Job Payloads**: Always carry both `schemaVersion` and `pipelineVersion`.
4. **CI Drift Detection**: CI fails if committed generated files diverge from schemas (`git diff --exit-code`).
