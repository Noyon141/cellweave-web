/**
 * CellWeave Cross-Language Contracts — Generated TypeScript Definitions
 * 
 * AUTOMATICALLY GENERATED FROM CANONICAL JSON SCHEMAS & OPENAPI 3.1.
 * DO NOT EDIT MANUALLY.
 * 
 * Single source of truth: /schemas/ and /openapi/
 */

// --- Branded Domain IDs ---
export type Brand<K, T> = K & { readonly __brand: T };

export type OrganizationId = Brand<string, 'OrganizationId'>;
export type ProjectId = Brand<string, 'ProjectId'>;
export type AnalysisRunId = Brand<string, 'AnalysisRunId'>;
export type DatasetVersionId = Brand<string, 'DatasetVersionId'>;
export type ArtifactId = Brand<string, 'ArtifactId'>;
export type StepId = Brand<string, 'StepId'>;

// --- Domain State Vocabularies ---

export const RUN_STATES = [
  'DRAFT',
  'UPLOADING',
  'VALIDATING',
  'QC_RUNNING',
  'QC_REVIEW_REQUIRED',
  'QUEUED',
  'RUNNING',
  'PAUSED_QUOTA',
  'CANCEL_REQUESTED',
  'CANCELLED',
  'SUCCEEDED',
  'FAILED',
] as const;
export type RunState = (typeof RUN_STATES)[number];

export const WORKFLOW_STEP_STATES = [
  'PENDING',
  'QUEUED',
  'RUNNING',
  'SUCCEEDED',
  'RETRYING',
  'FAILED',
  'SKIPPED',
  'CANCELLED',
] as const;
export type WorkflowStepState = (typeof WORKFLOW_STEP_STATES)[number];

export const UPLOAD_STATES = [
  'CREATED',
  'UPLOADING',
  'UPLOADED',
  'VERIFYING',
  'VERIFIED',
  'IMPORTED',
  'FAILED',
  'ABORTED',
  'EXPIRED',
  'QUARANTINED',
] as const;
export type UploadState = (typeof UPLOAD_STATES)[number];

export const ACCOUNT_STATES = [
  'ACTIVE',
  'PAST_DUE',
  'SUSPENDED',
  'CLOSING',
  'DELETED',
] as const;
export type AccountState = (typeof ACCOUNT_STATES)[number];

export const RESOURCE_CLASSES = [
  'CPU_SMALL',
  'CPU_MEMORY',
  'CPU_HIGH_MEMORY',
  'GPU_SMALL',
  'GPU_LARGE',
] as const;
export type ResourceClass = (typeof RESOURCE_CLASSES)[number];

export const ARTIFACT_TYPES = [
  'SOURCE_DATASET',
  'CANONICAL_DATASET',
  'QC_REPORT',
  'NORMALIZED_DATASET',
  'EMBEDDING',
  'CLUSTERS',
  'ANNOTATIONS',
  'MARKER_TABLE',
  'DE_TABLE',
  'PATHWAY_TABLE',
  'FIGURE',
  'REPORT',
  'RUN_MANIFEST',
  'EXPORT_BUNDLE',
] as const;
export type ArtifactType = (typeof ARTIFACT_TYPES)[number];

export const SCIENTIFIC_JOB_TYPES = [
  'validate_dataset',
  'run_qc',
  'filter_cells',
  'normalize',
  'select_hvg',
  'run_pca',
  'build_neighbors',
  'run_umap',
  'cluster',
  'annotate',
  'find_markers',
  'run_differential_expression',
  'run_pathway_analysis',
  'generate_exports',
] as const;
export type ScientificJobType = (typeof SCIENTIFIC_JOB_TYPES)[number];

// --- Domain Error Contract ---

export interface DomainError {
  readonly code: string;
  readonly message: string;
  readonly technicalDetail: string;
  readonly recommendedAction: string;
  readonly correlationId: string;
  readonly retryable?: boolean;
  readonly details?: Record<string, unknown>;
}

// --- Compute Provider Contracts ---

export interface ComputeJobSubmitRequest {
  readonly jobId: string;
  readonly jobType: string;
  readonly resourceClass: ResourceClass;
  readonly payloadUri: string;
  readonly maxRuntimeSeconds: number;
  readonly correlationId: string;
  readonly tags?: Record<string, string>;
}

export interface ComputeJobStatusResponse {
  readonly jobId: string;
  readonly providerJobId: string;
  readonly status: 'PENDING' | 'RUNNING' | 'COMPLETED' | 'FAILED' | 'CANCELLED' | 'TIMEOUT';
  readonly startedAt: string;
  readonly completedAt?: string;
  readonly exitCode?: number;
  readonly errorMessage?: string;
}

export interface ComputeJobCancelRequest {
  readonly jobId: string;
  readonly providerJobId: string;
  readonly reason: string;
}

export interface ComputeJobMetrics {
  readonly cpuSeconds: number;
  readonly gpuSeconds?: number;
  readonly memoryMegabyteSeconds: number;
  readonly peakMemoryBytes?: number;
}

export interface ComputeJobResultResponse {
  readonly jobId: string;
  readonly providerJobId: string;
  readonly status: 'COMPLETED' | 'FAILED' | 'CANCELLED';
  readonly resultUri?: string;
  readonly metrics: ComputeJobMetrics;
  readonly error?: DomainError;
}

export interface ComputeProvider {
  submit(request: ComputeJobSubmitRequest): Promise<ComputeJobStatusResponse>;
  status(jobId: string, providerJobId: string): Promise<ComputeJobStatusResponse>;
  cancel(request: ComputeJobCancelRequest): Promise<ComputeJobStatusResponse>;
  result(jobId: string, providerJobId: string): Promise<ComputeJobResultResponse>;
}

// --- Scientific Job Contract ---

export interface ScopedPrimaryDatasetInput {
  readonly downloadUrl: string;
  readonly sha256: string;
  readonly format?: string;
}

export interface ScopedAuxiliaryInput {
  readonly name: string;
  readonly downloadUrl: string;
  readonly sha256: string;
}

export interface ScopedOutputTarget {
  readonly name: string;
  readonly uploadUrl: string;
  readonly expectedMimeType: string;
}

export interface ScientificJobPayload {
  readonly schemaVersion: string;
  readonly pipelineVersion: string;
  readonly jobId: string;
  readonly runId: string;
  readonly stepId: string;
  readonly jobType: ScientificJobType;
  readonly resourceClass?: ResourceClass;
  readonly inputs: {
    readonly primaryDataset: ScopedPrimaryDatasetInput;
    readonly auxiliaryInputs?: readonly ScopedAuxiliaryInput[];
  };
  readonly outputs: {
    readonly targets: readonly ScopedOutputTarget[];
  };
  readonly parameters: Record<string, unknown>;
  readonly manifestFragment: {
    readonly containerDigest: string;
    readonly randomSeeds: Record<string, number>;
    readonly softwareVersions?: Record<string, string>;
    readonly [key: string]: unknown;
  };
}

// --- Manifest Contracts ---

export interface RunManifestStep {
  readonly stepId: string;
  readonly name: string;
  readonly version?: string;
  readonly status: WorkflowStepState;
  readonly startedAt: string;
  readonly completedAt: string;
  readonly computeUnits?: number;
  readonly resourceClass?: ResourceClass;
  readonly outputArtifactIds?: readonly string[];
}

export interface RunManifestArtifactSummary {
  readonly artifactId: string;
  readonly type: string;
  readonly sha256: string;
  readonly objectKey: string;
  readonly sizeBytes?: number;
}

export interface ScientificWarning {
  readonly code: string;
  readonly message: string;
  readonly step: string;
  readonly details?: Record<string, unknown>;
}

export interface RunManifest {
  readonly schemaVersion: string;
  readonly runId: string;
  readonly pipeline: {
    readonly name: string;
    readonly version: string;
  };
  readonly container: {
    readonly digest: string;
    readonly image?: string;
  };
  readonly input: {
    readonly datasetVersionId: string;
    readonly sha256: string;
    readonly sourceFormat?: string;
  };
  readonly organism: 'human' | 'mouse';
  readonly parameters: Record<string, unknown>;
  readonly references: {
    readonly genomeBuild?: string;
    readonly annotationModel?: {
      readonly name?: string;
      readonly version?: string;
      readonly referenceDataset?: string;
      readonly [key: string]: unknown;
    };
    readonly pathwayDatabase?: {
      readonly name?: string;
      readonly version?: string;
      readonly [key: string]: unknown;
    };
    readonly [key: string]: unknown;
  };
  readonly software: Record<string, string>;
  readonly randomSeeds: Record<string, number>;
  readonly steps: readonly RunManifestStep[];
  readonly artifacts: readonly RunManifestArtifactSummary[];
  readonly warnings?: readonly ScientificWarning[];
  readonly timestamps: {
    readonly startedAt: string;
    readonly completedAt: string;
  };
}

export interface ArtifactLineageRelation {
  readonly parentArtifactId: string;
  readonly relationship: string;
}

export interface ArtifactStorageRef {
  readonly provider: 'R2' | 'S3_COMPATIBLE';
  readonly bucket: string;
  readonly objectKey: string;
}

export interface ArtifactManifest {
  readonly schemaVersion: string;
  readonly artifactId: string;
  readonly runId: string;
  readonly type: ArtifactType;
  readonly storage: ArtifactStorageRef;
  readonly sha256: string;
  readonly sizeBytes: number;
  readonly mimeType: string;
  readonly producingStepId: string;
  readonly lineage: readonly ArtifactLineageRelation[];
  readonly metadata?: Record<string, unknown>;
  readonly createdAt: string;
}

// --- Event Contracts ---

export interface UsageMeasurements {
  readonly cpuSeconds: number;
  readonly gpuSeconds?: number;
  readonly memoryClass?: ResourceClass;
  readonly bytesProcessed?: number;
  readonly storageByteHours?: number;
  readonly egressBytes?: number;
}

export interface UsageEvent {
  readonly schemaVersion: string;
  readonly idempotencyKey: string;
  readonly organizationId: string;
  readonly projectId: string;
  readonly runId: string;
  readonly stepId: string;
  readonly attempt: number;
  readonly measurements: UsageMeasurements;
  readonly timestamp: string;
}

export interface AuditActor {
  readonly actorId: string;
  readonly actorType: 'USER' | 'SYSTEM' | 'SUPPORT_STAFF_BREAKGLASS';
  readonly ipAddress?: string;
  readonly userAgent?: string;
}

export interface AuditEvent {
  readonly schemaVersion: string;
  readonly eventId: string;
  readonly organizationId: string;
  readonly actor: AuditActor;
  readonly action: string;
  readonly resourceType: string;
  readonly resourceId: string;
  readonly metadata?: Record<string, unknown>;
  readonly timestamp: string;
}

export interface ServiceEvent {
  readonly schemaVersion: string;
  readonly eventId: string;
  readonly eventType: string;
  readonly source: string;
  readonly correlationId: string;
  readonly organizationId?: string;
  readonly data: Record<string, unknown>;
  readonly timestamp: string;
}

export interface PolarWebhookReceipt {
  readonly schemaVersion: string;
  readonly receiptId: string;
  readonly externalEventId: string;
  readonly eventType: string;
  readonly receivedAt: string;
  readonly signatureVerified?: boolean;
  readonly payload: Record<string, unknown>;
}

// --- OpenAPI Phase 0 API Models ---

export interface HealthResponse {
  readonly status: 'healthy' | 'degraded' | 'unhealthy';
  readonly version: string;
  readonly schemaVersion: string;
  readonly timestamp: string;
}
