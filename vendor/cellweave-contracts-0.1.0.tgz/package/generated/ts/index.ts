/**
 * CellWeave Cross-Language Contracts — Generated TypeScript Definitions
 * 
 * AUTOMATICALLY GENERATED FROM CANONICAL JSON SCHEMAS & OPENAPI 3.1.
 * DO NOT EDIT MANUALLY.
 * 
 * Single source of truth: /schemas/ and /openapi/
 */

// --- Branded Domain IDs ---
export type Brand<K, T> = K & { readonly __brand: T };

export type OrganizationId = Brand<string, 'OrganizationId'>;
export type ProjectId = Brand<string, 'ProjectId'>;
export type AnalysisRunId = Brand<string, 'AnalysisRunId'>;
export type DatasetVersionId = Brand<string, 'DatasetVersionId'>;
export type ArtifactId = Brand<string, 'ArtifactId'>;
export type StepId = Brand<string, 'StepId'>;
export type DatasetFileId = Brand<string, 'DatasetFileId'>;
export type ImportId = Brand<string, 'ImportId'>;

// --- Domain State Vocabularies ---

export const RUN_STATES = [
  'DRAFT',
  'UPLOADING',
  'START_PENDING',
  'VALIDATING',
  'QC_RUNNING',
  'QC_REVIEW_REQUIRED',
  'QUEUED',
  'RUNNING',
  'PAUSED_QUOTA',
  'CANCEL_REQUESTED',
  'CANCELLED',
  'SUCCEEDED',
  'FAILED',
] as const;
export type RunState = (typeof RUN_STATES)[number];

export const WORKFLOW_STEP_STATES = [
  'PENDING',
  'QUEUED',
  'RUNNING',
  'SUCCEEDED',
  'RETRYING',
  'FAILED',
  'SKIPPED',
  'CANCELLED',
] as const;
export type WorkflowStepState = (typeof WORKFLOW_STEP_STATES)[number];

export const UPLOAD_STATES = [
  'CREATED',
  'UPLOADING',
  'UPLOADED',
  'VERIFYING',
  'VERIFIED',
  'IMPORTED',
  'FAILED',
  'ABORTED',
  'EXPIRED',
  'QUARANTINED',
] as const;
export type UploadState = (typeof UPLOAD_STATES)[number];

export const ACCOUNT_STATES = [
  'ACTIVE',
  'PAST_DUE',
  'SUSPENDED',
  'CLOSING',
  'DELETED',
] as const;
export type AccountState = (typeof ACCOUNT_STATES)[number];

export const RESOURCE_CLASSES = [
  'CPU_SMALL',
  'CPU_MEMORY',
  'CPU_HIGH_MEMORY',
  'GPU_SMALL',
  'GPU_LARGE',
] as const;
export type ResourceClass = (typeof RESOURCE_CLASSES)[number];

export const ARTIFACT_TYPES = [
  'SOURCE_DATASET',
  'CANONICAL_DATASET',
  'QC_REPORT',
  'NORMALIZED_DATASET',
  'EMBEDDING',
  'CLUSTERS',
  'ANNOTATIONS',
  'MARKER_TABLE',
  'DE_TABLE',
  'PATHWAY_TABLE',
  'FIGURE',
  'REPORT',
  'RUN_MANIFEST',
  'EXPORT_BUNDLE',
  'FILTERED_DATASET',
] as const;
export type ArtifactType = (typeof ARTIFACT_TYPES)[number];

export const SCIENTIFIC_JOB_TYPES = [
  'validate_dataset',
  'run_qc',
  'filter_cells',
  'normalize',
  'select_hvg',
  'run_pca',
  'build_neighbors',
  'run_umap',
  'cluster',
  'annotate',
  'find_markers',
  'run_differential_expression',
  'run_pathway_analysis',
  'generate_exports',
] as const;
export type ScientificJobType = (typeof SCIENTIFIC_JOB_TYPES)[number];

// --- Tenancy & Identity Contracts ---

export const ORGANIZATION_ROLES = [
  'owner',
  'admin',
  'bioinformatician',
  'scientist',
  'viewer',
] as const;
export type OrganizationRole = (typeof ORGANIZATION_ROLES)[number];

export interface TenantContext {
  readonly organizationId: string;
  readonly userId: string;
  readonly role: OrganizationRole;
}

// --- Domain Error Contract ---

export interface DomainError {
  readonly code: string;
  readonly message: string;
  readonly technicalDetail: string;
  readonly recommendedAction: string;
  readonly correlationId: string;
  readonly retryable?: boolean;
  readonly details?: Record<string, unknown>;
}

// --- Compute Provider Contracts ---

export interface ComputeJobSubmitRequest {
  readonly execution?: PreparedExecution;
  readonly qcExecution?: QcPreparedExecution;
  readonly jobId: string;
  readonly jobType: string;
  readonly resourceClass: ResourceClass;
  readonly payloadUri: string;
  readonly maxRuntimeSeconds: number;
  readonly correlationId: string;
  readonly tags?: Record<string, string>;
}

export interface ComputeJobStatusResponse {
  readonly jobId: string;
  readonly providerJobId: string;
  readonly status: 'PENDING' | 'RUNNING' | 'COMPLETED' | 'FAILED' | 'CANCELLED' | 'TIMEOUT' | 'UNKNOWN';
  readonly startedAt: string;
  readonly completedAt?: string;
  readonly exitCode?: number;
  readonly errorMessage?: string;
}

export interface ComputeJobCancelRequest {
  readonly jobId: string;
  readonly providerJobId?: string;
  readonly reason: string;
}

export interface ComputeJobMetrics {
  readonly cpuSeconds: number;
  readonly gpuSeconds?: number;
  readonly memoryMegabyteSeconds: number;
  readonly peakMemoryBytes?: number;
}

export interface ComputeJobResultResponse {
  readonly executionResult?: ExecutionResult;
  readonly qcResult?: QcJobResult;
  readonly jobId: string;
  readonly providerJobId: string;
  readonly status: 'COMPLETED' | 'FAILED' | 'CANCELLED';
  readonly resultUri?: string;
  readonly metrics: ComputeJobMetrics;
  readonly error?: DomainError;
}

export interface ComputeProvider {
  submit(request: ComputeJobSubmitRequest): Promise<ComputeJobStatusResponse>;
  status(jobId: string, providerJobId: string): Promise<ComputeJobStatusResponse>;
  cancel(request: ComputeJobCancelRequest): Promise<ComputeCancellationResponse>;
  result(jobId: string, providerJobId: string): Promise<ComputeJobResultResponse>;
}

// --- Scientific Job Contract ---

export interface ScopedPrimaryDatasetInput {
  readonly downloadUrl: string;
  readonly sha256: string;
  readonly format?: string;
}

export interface ScopedAuxiliaryInput {
  readonly name: string;
  readonly downloadUrl: string;
  readonly sha256: string;
}

export interface ScopedOutputTarget {
  readonly name: string;
  readonly uploadUrl: string;
  readonly expectedMimeType: string;
}

export interface ScientificJobPayload {
  readonly schemaVersion: string;
  readonly pipelineVersion: string;
  readonly jobId: string;
  readonly runId: string;
  readonly stepId: string;
  readonly jobType: ScientificJobType;
  readonly resourceClass?: ResourceClass;
  readonly inputs: {
    readonly primaryDataset: ScopedPrimaryDatasetInput;
    readonly auxiliaryInputs?: readonly ScopedAuxiliaryInput[];
  };
  readonly outputs: {
    readonly targets: readonly ScopedOutputTarget[];
  };
  readonly parameters: Record<string, unknown>;
  readonly manifestFragment: {
    readonly containerDigest: string;
    readonly randomSeeds: Record<string, number>;
    readonly softwareVersions?: Record<string, string>;
    readonly [key: string]: unknown;
  };
}

// --- Manifest Contracts ---

export interface RunManifestStep {
  readonly stepId: string;
  readonly name: string;
  readonly version?: string;
  readonly status: WorkflowStepState;
  readonly startedAt: string;
  readonly completedAt: string;
  readonly computeUnits?: number;
  readonly resourceClass?: ResourceClass;
  readonly outputArtifactIds?: readonly string[];
}

export interface RunManifestArtifactSummary {
  readonly artifactId: string;
  readonly type: string;
  readonly sha256: string;
  readonly objectKey: string;
  readonly sizeBytes?: number;
}

export interface ScientificWarning {
  readonly code: string;
  readonly message: string;
  readonly step: string;
  readonly details?: Record<string, unknown>;
}

export interface RunManifest {
  readonly schemaVersion: string;
  readonly runId: string;
  readonly pipeline: {
    readonly name: string;
    readonly version: string;
  };
  readonly container: {
    readonly digest: string;
    readonly image?: string;
  };
  readonly input: {
    readonly datasetVersionId: string;
    readonly sha256: string;
    readonly sourceFormat?: string;
  };
  readonly organism: 'human' | 'mouse';
  readonly parameters: Record<string, unknown>;
  readonly references: {
    readonly genomeBuild?: string;
    readonly annotationModel?: {
      readonly name?: string;
      readonly version?: string;
      readonly referenceDataset?: string;
      readonly [key: string]: unknown;
    };
    readonly pathwayDatabase?: {
      readonly name?: string;
      readonly version?: string;
      readonly [key: string]: unknown;
    };
    readonly [key: string]: unknown;
  };
  readonly software: Record<string, string>;
  readonly randomSeeds: Record<string, number>;
  readonly steps: readonly RunManifestStep[];
  readonly artifacts: readonly RunManifestArtifactSummary[];
  readonly warnings?: readonly ScientificWarning[];
  readonly timestamps: {
    readonly startedAt: string;
    readonly completedAt: string;
  };
}

export interface ArtifactLineageRelation {
  readonly parentArtifactId: string;
  readonly relationship: string;
}

export interface ArtifactStorageRef {
  readonly provider: 'R2' | 'S3_COMPATIBLE';
  readonly bucket: string;
  readonly objectKey: string;
}

export interface ArtifactManifest {
  readonly schemaVersion: string;
  readonly artifactId: string;
  readonly runId: string;
  readonly type: ArtifactType;
  readonly storage: ArtifactStorageRef;
  readonly sha256: string;
  readonly sizeBytes: number;
  readonly mimeType: string;
  readonly producingStepId: string;
  readonly lineage: readonly ArtifactLineageRelation[];
  readonly metadata?: Record<string, unknown>;
  readonly createdAt: string;
}

// --- Event Contracts ---

export interface UsageMeasurements {
  readonly cpuSeconds: number;
  readonly gpuSeconds?: number;
  readonly memoryClass?: ResourceClass;
  readonly bytesProcessed?: number;
  readonly storageByteHours?: number;
  readonly egressBytes?: number;
}

export interface UsageEvent {
  readonly schemaVersion: string;
  readonly idempotencyKey: string;
  readonly organizationId: string;
  readonly projectId: string;
  readonly runId: string;
  readonly stepId: string;
  readonly attempt: number;
  readonly measurements: UsageMeasurements;
  readonly timestamp: string;
}

export interface AuditActor {
  readonly actorId: string;
  readonly actorType: string;
  readonly ipHash?: string;
  readonly userAgent?: string;
}

export interface AuditEvent {
  readonly schemaVersion: string;
  readonly eventId: string;
  readonly organizationId: string;
  readonly actor: AuditActor;
  readonly action: string;
  readonly resourceType: string;
  readonly resourceId: string;
  readonly metadata?: Record<string, unknown>;
  readonly timestamp: string;
}

export interface ServiceEvent {
  readonly schemaVersion: string;
  readonly eventId: string;
  readonly eventType: string;
  readonly source: string;
  readonly correlationId: string;
  readonly organizationId?: string;
  readonly data: Record<string, unknown>;
  readonly timestamp: string;
}

export interface PolarWebhookReceipt {
  readonly schemaVersion: string;
  readonly receiptId: string;
  readonly externalEventId: string;
  readonly eventType: string;
  readonly receivedAt: string;
  readonly signatureVerified?: boolean;
  readonly payload: Record<string, unknown>;
}

// --- OpenAPI Phase 0 API Models ---

export interface HealthResponse {
  readonly status: 'healthy' | 'degraded' | 'unhealthy';
  readonly version: string;
  readonly schemaVersion: string;
  readonly timestamp: string;
}

// --- Phase 3 Scientific Import Contracts ---

export const SOURCE_FORMATS = [
  'H5AD',
  'TENX_H5',
  'TENX_MTX',
  'GENERIC_MATRIX',
] as const;
export type SourceFormat = (typeof SOURCE_FORMATS)[number];

export const IMPORT_FILE_ROLES = [
  'PRIMARY',
  'MATRIX',
  'FEATURES',
  'BARCODES',
  'CELL_METADATA',
  'FEATURE_METADATA',
] as const;
export type ImportFileRole = (typeof IMPORT_FILE_ROLES)[number];

export const ORGANISMS = [
  'HUMAN',
  'MOUSE',
] as const;
export type Organism = (typeof ORGANISMS)[number];

export const GENE_ID_SCHEMES = [
  'ENSEMBL',
  'SYMBOL',
] as const;
export type GeneIdScheme = (typeof GENE_ID_SCHEMES)[number];

export const MATRIX_ORIENTATIONS = [
  'CELLS_BY_GENES',
  'GENES_BY_CELLS',
] as const;
export type MatrixOrientation = (typeof MATRIX_ORIENTATIONS)[number];

export const INSPECTION_STATUSES = [
  'VALID',
  'NEEDS_MAPPING',
  'INVALID',
] as const;
export type InspectionStatus = (typeof INSPECTION_STATUSES)[number];

export const SCIENTIFIC_ISSUE_CODES = [
  'UNSUPPORTED_FORMAT',
  'FORMAT_MISMATCH',
  'MALFORMED_INPUT',
  'MISSING_COMPONENT',
  'INVALID_IMPORT_CARDINALITY',
  'DIMENSION_MISMATCH',
  'DUPLICATE_CELL_IDS',
  'AMBIGUOUS_GENE_IDENTIFIERS',
  'AMBIGUOUS_ORIENTATION',
  'MISSING_REQUIRED_METADATA',
  'UNRESOLVED_SPECIES',
  'UNSUPPORTED_SPECIES',
  'UNSUPPORTED_MODALITY',
  'NON_COUNT_INPUT',
  'AMBIGUOUS_COUNT_SEMANTICS',
  'RESOURCE_LIMIT',
  'SECURITY_REJECTED',
  'CANONICALIZATION_FAILED',
] as const;
export type ScientificIssueCode = (typeof SCIENTIFIC_ISSUE_CODES)[number];

export const SCIENTIFIC_ISSUE_SEVERITIES = [
  'ERROR',
  'WARNING',
  'REQUIRES_USER_INPUT',
] as const;
export type ScientificIssueSeverity = (typeof SCIENTIFIC_ISSUE_SEVERITIES)[number];

export const CANONICAL_ARTIFACT_PUBLICATION_STATUSES = [
  'PUBLISHED',
  'ALREADY_PRESENT',
] as const;
export type CanonicalArtifactPublicationStatus = (typeof CANONICAL_ARTIFACT_PUBLICATION_STATUSES)[number];

export interface ScientificIssue {
  readonly code: ScientificIssueCode;
  readonly severity: ScientificIssueSeverity;
  readonly message: string;
  readonly field?: string;
  readonly userActionRequired: boolean;
}

export interface SelectedImportFile {
  readonly datasetFileId: string;
  readonly role: ImportFileRole;
  readonly ordinal: number;
}

export interface RegisterManifestRequest {
  readonly datasetVersionId: string;
  readonly files: readonly SelectedImportFile[];
}

export interface RegisterManifestResponse {
  readonly importId: string;
  readonly datasetVersionId: string;
  readonly sourceFormat: SourceFormat;
  readonly sourceChecksum: string;
  readonly fileCount: number;
}

export interface ManifestFileItem {
  readonly datasetFileId: string;
  readonly fileName: string;
  readonly role: ImportFileRole;
  readonly ordinal: number;
  readonly byteSize: number;
  readonly sha256: string;
}

export interface DatasetImportManifest {
  readonly id: string;
  readonly organizationId: string;
  readonly datasetVersionId: string;
  readonly sourceFormat: SourceFormat;
  readonly sourceChecksum: string;
  readonly files: readonly ManifestFileItem[];
  readonly createdAt: string;
}

export interface ImportInspectionResult {
  readonly datasetVersionId: string;
  readonly sourceFormat: SourceFormat;
  readonly status: InspectionStatus;
  readonly cellCountEstimate?: number | null;
  readonly geneCountEstimate?: number | null;
  readonly detectedOrganism?: Organism | null;
  readonly detectedGeneIdScheme?: GeneIdScheme | null;
  readonly referenceBuildCandidate?: string | null;
  readonly requiresMapping: boolean;
  readonly availableCellMetadataColumns: readonly string[];
  readonly availableFeatureMetadataColumns: readonly string[];
  readonly issues: readonly ScientificIssue[];
}

export interface SampleMappingEntry {
  readonly sourceValue: string;
  readonly sampleKey: string;
}

export interface MetadataMappingSubmission {
  readonly datasetVersionId: string;
  readonly organism: Organism;
  readonly geneIdScheme: GeneIdScheme;
  readonly referenceBuild?: string | null;
  readonly orientation?: MatrixOrientation;
  readonly cellIdColumn?: string | null;
  readonly geneIdColumn?: string | null;
  readonly geneSymbolColumn?: string | null;
  readonly matrixCellIdColumn?: string | null;
  readonly matrixFeatureIdColumn?: string | null;
  readonly cellMetadataJoinColumn?: string | null;
  readonly featureMetadataJoinColumn?: string | null;
  readonly cellAxisIndexColumn?: string | null;
  readonly featureAxisIndexColumn?: string | null;
  readonly sampleColumn?: string | null;
  readonly conditionColumn?: string | null;
  readonly batchColumn?: string | null;
  readonly biologicalReplicateColumn?: string | null;
  readonly technicalReplicateColumn?: string | null;
  readonly sampleMappings?: readonly SampleMappingEntry[];
}

export interface SourceFileTarget {
  readonly datasetFileId: string;
  readonly role: ImportFileRole;
  readonly ordinal: number;
  readonly localPath: string;
}

export interface CanonicalizationRequest {
  readonly datasetVersionId: string;
  readonly importId: string;
  readonly sourceFormat: SourceFormat;
  readonly sourceFiles: readonly SourceFileTarget[];
  readonly organism: Organism;
  readonly geneIdScheme: GeneIdScheme;
  readonly referenceBuild?: string | null;
  readonly mapping?: MetadataMappingSubmission | null;
}

export interface CanonicalizationResult {
  readonly sourceFormat: SourceFormat;
  readonly canonicalFormat: 'H5AD';
  readonly canonicalChecksum: string;
  readonly organism: Organism;
  readonly geneIdScheme: GeneIdScheme;
  readonly referenceBuild?: string | null;
  readonly cellCount: number;
  readonly geneCount: number;
  readonly warnings: readonly ScientificIssue[];
  readonly localArtifactPath?: string | null;
}

/**
 * INTERNAL TRUSTED WORKER/CONTROL-PLANE CONTRACT ONLY.
 * Never accepted from browser/client input.
 * putUrl and getUrl are ephemeral secret capabilities and MUST be redacted from logs and errors.
 */
export interface CanonicalArtifactPublicationCapabilities {
  readonly datasetVersionId: string;
  readonly putUrl: string;
  readonly getUrl: string;
  readonly expiresAt: string;
  readonly requiredPutHeaders: {
    readonly 'If-None-Match': '*';
    readonly [headerName: string]: string;
  };
  readonly requiredGetHeaders: Readonly<Record<string, string>>;
}

/**
 * INTERNAL TRUSTED WORKER/CONTROL-PLANE CONTRACT ONLY.
 * Result of publishing and verifying a canonical.h5ad artifact via scoped capabilities.
 * Integrity conflicts must fail as errors rather than returning a success status.
 */
export interface CanonicalArtifactPublicationResult {
  readonly datasetVersionId: string;
  readonly canonicalChecksum: string;
  readonly byteSize: number;
  readonly status: CanonicalArtifactPublicationStatus;
}



export const SERVICE_SCOPES = ["execution.prepare","execution.project","execution.finalize","execution.cancel","capability.issue"] as const;
export type ServiceScope = (typeof SERVICE_SCOPES)[number];

export const SERVICE_ENVIRONMENTS = ["local","development","staging","production"] as const;
export type ServiceEnvironment = (typeof SERVICE_ENVIRONMENTS)[number];

// Internal Phase 4 execution contracts, generated from workflow-execution.v1.json.
export interface ExecutionCeilings {
  readonly resourceClass: ResourceClass;
  readonly estimatedComputeUnits: number;
  readonly maxComputeUnits: number;
  readonly maxRuntimeSeconds: number;
  readonly maxMemoryClass: ResourceClass;
  readonly maxInputBytes: number;
  readonly maxDecompressedBytes: number;
  readonly maxCompressionRatio: number;
}
export interface ExecutionEnvelope {
  readonly schemaVersion: "1.0.0";
  readonly analysisRunId: string;
  readonly organizationId: string;
  readonly projectId: string;
  readonly datasetVersionId: string;
  readonly importId: string;
  readonly pipelineVersion: string;
  readonly stepId: string;
  readonly submissionId: string;
  readonly ceilings: ExecutionCeilings;
  readonly organism: Organism;
  readonly geneIdScheme: GeneIdScheme;
  readonly referenceBuild: string | null;
  readonly mapping?: MetadataMappingSubmission;
  readonly deadlineAt: string;
  readonly environment: ServiceEnvironment;
}
export interface ExecutionSourceCapability {
  readonly datasetFileId: string;
  readonly fileName: string;
  readonly byteSize: number;
  readonly sha256: string;
  readonly role: ImportFileRole;
  readonly ordinal: number;
  readonly downloadUrl: string;
}
export interface PreparedExecution {
  readonly envelope: ExecutionEnvelope;
  readonly sourceFormat: SourceFormat;
  readonly sourceChecksum: string;
  readonly files: ReadonlyArray<ExecutionSourceCapability>;
  readonly publication: CanonicalArtifactPublicationCapabilities;
}
export interface ExecutionResult {
  readonly analysisRunId: string;
  readonly submissionId: string;
  readonly publication: CanonicalArtifactPublicationResult;
  readonly canonicalization: CanonicalizationResult;
  readonly usage?: ExecutionUsage;
}
export interface ExecutionProjection {
  readonly analysisRunId: string;
  readonly sequence: number;
  readonly status: RunState;
  readonly stepState: WorkflowStepState;
  readonly failureCode?: string;
}
export interface ExecutionControl {
  readonly analysisRunId: string;
  readonly status: RunState;
  readonly cancelRequested: boolean;
  readonly projectionVersion: number;
  readonly providerJobId: string | null;
  readonly providerState: "UNKNOWN" | "PENDING" | "RUNNING" | "COMPLETED" | "FAILED" | "CANCELLED" | "TIMEOUT";
  readonly finalizationStarted: boolean;
  readonly result: ExecutionResult | null;
  readonly submissionId: string;
}
export interface ComputeCancellationResponse {
  readonly jobId: string;
  readonly providerJobId?: string;
  readonly status: "UNKNOWN" | "PENDING" | "RUNNING" | "COMPLETED" | "FAILED" | "CANCELLED" | "TIMEOUT";
  readonly startedAt: string;
  readonly completedAt?: string;
  readonly exitCode?: number;
  readonly errorMessage?: string;
}
export interface ExecutionUsage {
  readonly cpuSeconds: number;
  readonly gpuSeconds?: number;
  readonly memoryMegabyteSeconds: number;
  readonly peakMemoryBytes?: number;
}
export interface QcIssue {
  readonly code: "ZERO_COUNT_PERCENTAGE_UNAVAILABLE" | "GENE_SYMBOLS_REQUIRED_FOR_QC_GENE_SET" | "SAMPLE_ASSIGNMENT_UNAVAILABLE" | "CAPTURE_GROUP_UNRESOLVED" | "INSUFFICIENT_CELLS" | "INSUFFICIENT_FEATURES" | "DEGENERATE_DATA" | "THRESHOLD_INFERENCE_FAILED" | "SCRUBLET_FAILED";
  readonly groupKey: string | null;
  readonly affectedCells: number;
}
export interface QcSampleBinding {
  readonly sampleId: string;
  readonly sampleKey: string;
  readonly captureGroupKey: string | null;
  readonly expectedDoubletRate: number | null;
}
export interface QcAnalysisParameters {
  readonly geneSetPolicy: "cellweave-symbol-prefixes-v1";
  readonly scrubletProfile: "cellweave-scanpy-scrublet-v1";
  readonly randomSeed: number;
  readonly samples: ReadonlyArray<QcSampleBinding>;
  readonly wholeInputSampleId: string | null;
}
export interface QcCaptureRequest {
  readonly sampleId: string;
  readonly captureGroupKey: string;
}
export interface QcStartRequest {
  readonly datasetVersionId: string;
  readonly captureBindings: ReadonlyArray<QcCaptureRequest>;
  readonly wholeInputSampleId: string | null;
}
export interface QcThresholdRule {
  readonly metric: "total_counts" | "n_genes_by_counts" | "total_counts_mt" | "pct_counts_mt" | "total_counts_ribo" | "pct_counts_ribo";
  readonly minimum: number | null;
  readonly maximum: number | null;
  readonly sampleKey: string | null;
}
export interface QcSelectionParameters {
  readonly thresholds: ReadonlyArray<QcThresholdRule>;
  readonly doubletHandling: "RETAIN" | "EXCLUDE_PREDICTED";
}
export interface QcApprovalRequest {
  readonly previewId: string;
  readonly reason: string;
}
export interface QcHistogramBin {
  readonly lower: number;
  readonly upper: number;
  readonly count: number;
}
export interface QcMetricSummary {
  readonly metric: "total_counts" | "n_genes_by_counts" | "total_counts_mt" | "pct_counts_mt" | "total_counts_ribo" | "pct_counts_ribo";
  readonly availableCells: number;
  readonly minimum: number | null;
  readonly maximum: number | null;
  readonly mean: number | null;
  readonly histogram: ReadonlyArray<QcHistogramBin>;
}
export interface QcSampleSummary {
  readonly sampleId: string;
  readonly sampleKey: string;
  readonly cellCount: number;
  readonly metrics: ReadonlyArray<QcMetricSummary>;
}
export interface QcSoftwareVersion {
  readonly name: string;
  readonly version: string;
}
export interface QcParameterValue {
  readonly name: string;
  readonly value: string;
}
export interface QcDoubletAssessment {
  readonly captureGroupKey: string;
  readonly status: "ASSESSED" | "NOT_ASSESSED";
  readonly reason: string | null;
  readonly cellCount: number;
  readonly threshold: number | null;
  readonly predictedCount: number | null;
  readonly parameters: ReadonlyArray<QcParameterValue>;
}
export interface QcSummary {
  readonly schemaVersion: "1.0.0";
  readonly geneSetPolicy: "cellweave-symbol-prefixes-v1";
  readonly scrubletProfile: "cellweave-scanpy-scrublet-v1";
  readonly randomSeed: number;
  readonly cellCount: number;
  readonly geneCount: number;
  readonly metrics: ReadonlyArray<QcMetricSummary>;
  readonly samples: ReadonlyArray<QcSampleSummary>;
  readonly sampleQcAvailable: boolean;
  readonly doublets: ReadonlyArray<QcDoubletAssessment>;
  readonly issues: ReadonlyArray<QcIssue>;
  readonly software: ReadonlyArray<QcSoftwareVersion>;
  readonly suggestions: ReadonlyArray<QcThresholdRule>;
}
export interface QcArtifactTarget {
  readonly artifactId: string;
  readonly type: "QC_REPORT" | "FILTERED_DATASET";
  readonly fileName: "qc_metrics.jsonl.gz" | "qc_summary.json" | "selection.jsonl.gz" | "filtered.h5ad";
  readonly putUrl: string;
  readonly getUrl: string;
  readonly expiresAt: string;
  readonly ifNoneMatch: "*";
}
export interface QcArtifactInput {
  readonly artifactId: string;
  readonly type: "CANONICAL_DATASET" | "QC_REPORT";
  readonly sha256: string;
  readonly byteSize: number;
  readonly downloadUrl: string;
}
export interface QcFilterBinding {
  readonly decisionId: string;
  readonly canonicalChecksum: string;
  readonly selectionArtifactId: string;
  readonly selectionChecksum: string;
  readonly parametersChecksum: string;
  readonly includedCount: number;
  readonly excludedCount: number;
}
export interface QcPreparedExecution {
  readonly schemaVersion: "1.0.0";
  readonly environment: ServiceEnvironment;
  readonly analysisRunId: string;
  readonly stepId: string;
  readonly submissionId: string;
  readonly pipelineVersion: string;
  readonly operation: "QC" | "PREVIEW" | "FILTER";
  readonly qcRevision: number;
  readonly deadlineAt: string;
  readonly ceilings: ExecutionCeilings;
  readonly canonical: QcArtifactInput;
  readonly auxiliary: ReadonlyArray<QcArtifactInput>;
  readonly targets: ReadonlyArray<QcArtifactTarget>;
  readonly analysis: QcAnalysisParameters;
  readonly selection: QcSelectionParameters | null;
  readonly decision: QcFilterBinding | null;
}
export interface QcProducedArtifact {
  readonly artifactId: string;
  readonly type: "QC_REPORT" | "FILTERED_DATASET";
  readonly fileName: "qc_metrics.jsonl.gz" | "qc_summary.json" | "selection.jsonl.gz" | "filtered.h5ad";
  readonly sha256: string;
  readonly byteSize: number;
  readonly status: "PUBLISHED" | "ALREADY_PRESENT";
}
export interface QcPreviewProof {
  readonly previewId: string;
  readonly qcRevision: number;
  readonly canonicalChecksum: string;
  readonly parametersChecksum: string;
  readonly selectionArtifactId: string;
  readonly selectionChecksum: string;
  readonly includedCount: number;
  readonly excludedCount: number;
}
export interface QcJobResult {
  readonly analysisRunId: string;
  readonly stepId: string;
  readonly submissionId: string;
  readonly operation: "QC" | "PREVIEW" | "FILTER";
  readonly artifacts: ReadonlyArray<QcProducedArtifact>;
  readonly summary: QcSummary | null;
  readonly preview: QcPreviewProof | null;
}
export interface QcDecision {
  readonly schemaVersion: "1.0.0";
  readonly id: string;
  readonly organizationId: string;
  readonly projectId: string;
  readonly analysisRunId: string;
  readonly datasetVersionId: string;
  readonly canonicalChecksum: string;
  readonly qcRevision: number;
  readonly preview: QcPreviewProof;
  readonly selection: QcSelectionParameters;
  readonly actorId: string;
  readonly createdAt: string;
  readonly reason: string;
  readonly geneSetPolicy: "cellweave-symbol-prefixes-v1";
  readonly scrubletProfile: "cellweave-scanpy-scrublet-v1";
}
export interface QcApprovalSignal {
  readonly schemaVersion: "1.0.0";
  readonly analysisRunId: string;
  readonly decisionId: string;
}
export interface QcStepContext {
  readonly operation: "QC" | "PREVIEW" | "FILTER";
  readonly revision: number;
  readonly selection: QcSelectionParameters | null;
  readonly decisionId: string | null;
  readonly outputIds: ReadonlyArray<string>;
  readonly deadlineAt: string | null;
}
export interface QcStepControl {
  readonly stepId: string;
  readonly submissionId: string;
  readonly status: WorkflowStepState;
  readonly providerJobId: string | null;
  readonly providerState: "UNKNOWN" | "PENDING" | "RUNNING" | "COMPLETED" | "FAILED" | "CANCELLED" | "TIMEOUT";
  readonly context: QcStepContext;
  readonly result: QcJobResult | null;
}
export interface QcControl {
  readonly analysisRunId: string;
  readonly status: RunState;
  readonly projectionVersion: number;
  readonly cancelRequested: boolean;
  readonly filterCommitted: boolean;
  readonly qcRevision: number;
  readonly steps: ReadonlyArray<QcStepControl>;
  readonly decision: QcDecision | null;
  readonly approvalPending: boolean;
}
export interface QcProjection {
  readonly analysisRunId: string;
  readonly sequence: number;
  readonly status: RunState;
}
export interface QcCellMetrics {
  readonly cellId: string;
  readonly sampleId: string | null;
  readonly sampleKey: string | null;
  readonly captureGroupKey: string | null;
  readonly total_counts: number;
  readonly n_genes_by_counts: number;
  readonly total_counts_mt: number | null;
  readonly pct_counts_mt: number | null;
  readonly total_counts_ribo: number | null;
  readonly pct_counts_ribo: number | null;
  readonly doublet_score: number | null;
  readonly predicted_doublet: boolean | null;
}
export interface QcSelectionHeader {
  readonly schemaVersion: "1.0.0";
  readonly previewId: string;
  readonly qcRevision: number;
  readonly canonicalChecksum: string;
  readonly parametersChecksum: string;
  readonly cellOrderChecksum: string;
  readonly includedCount: number;
  readonly excludedCount: number;
}
export interface QcSelectionRow {
  readonly cellId: string;
  readonly included: boolean;
}
export interface QcReviewView {
  readonly analysisRunId: string;
  readonly datasetVersionId: string;
  readonly status: RunState;
  readonly qcRevision: number;
  readonly summary: QcSummary | null;
  readonly preview: QcPreviewProof | null;
  readonly previewPending: boolean;
  readonly previewError: "QC_SELECTION_REJECTED" | null;
  readonly previewParameters: QcSelectionParameters | null;
  readonly decision: QcDecision | null;
  readonly canApprove: boolean;
  readonly filteredArtifactId: string | null;
}
export interface QcSampleOption {
  readonly sampleId: string;
  readonly sampleKey: string;
  readonly label: string;
}
export interface QcDatasetOption {
  readonly datasetVersionId: string;
  readonly label: string;
  readonly samples: ReadonlyArray<QcSampleOption>;
}
export interface QcInputOptions {
  readonly canStart: boolean;
  readonly datasets: ReadonlyArray<QcDatasetOption>;
}

export const RUN_TRANSITIONS = {"DRAFT":["UPLOADING","START_PENDING","CANCEL_REQUESTED"],"UPLOADING":["START_PENDING","FAILED","CANCEL_REQUESTED"],"START_PENDING":["QUEUED","FAILED","CANCEL_REQUESTED"],"QUEUED":["VALIDATING","RUNNING","FAILED","CANCEL_REQUESTED"],"VALIDATING":["RUNNING","FAILED","CANCEL_REQUESTED"],"RUNNING":["SUCCEEDED","FAILED","PAUSED_QUOTA","CANCEL_REQUESTED","QC_RUNNING"],"PAUSED_QUOTA":["QUEUED","FAILED","CANCEL_REQUESTED"],"CANCEL_REQUESTED":["CANCELLED","FAILED"],"QC_RUNNING":["QC_REVIEW_REQUIRED","FAILED","CANCEL_REQUESTED"],"QC_REVIEW_REQUIRED":["QUEUED","FAILED","CANCEL_REQUESTED"],"CANCELLED":[],"SUCCEEDED":[],"FAILED":[]} as const;

export const STEP_TRANSITIONS = {"PENDING":["QUEUED","CANCELLED","SKIPPED"],"QUEUED":["RUNNING","CANCELLED","FAILED"],"RUNNING":["SUCCEEDED","FAILED","RETRYING","CANCELLED"],"RETRYING":["RUNNING","FAILED","CANCELLED"],"SUCCEEDED":[],"FAILED":[],"SKIPPED":[],"CANCELLED":[]} as const;

export const EXECUTION_JSON_SCHEMAS = [{"$schema":"https://json-schema.org/draft/2020-12/schema","$id":"https://contracts.cellweave.dev/schemas/compute/compute-provider.v1.json","title":"ComputeProviderContracts","description":"Standardized abstraction contracts for compute providers (Modal, etc.) isolating compute execution from domain logic.","definitions":{"ComputeJobSubmitRequest":{"type":"object","required":["jobId","jobType","resourceClass","payloadUri","maxRuntimeSeconds","correlationId"],"properties":{"jobId":{"type":"string"},"jobType":{"type":"string"},"resourceClass":{"$ref":"https://contracts.cellweave.dev/schemas/domain/resource-class.v1.json"},"payloadUri":{"type":"string","description":"Signed capability URI or scoped storage reference for job payload."},"maxRuntimeSeconds":{"type":"integer","minimum":1},"correlationId":{"type":"string"},"tags":{"type":"object","additionalProperties":{"type":"string"}},"execution":{"$ref":"https://contracts.cellweave.dev/schemas/jobs/workflow-execution.v1.json#/$defs/PreparedExecution"},"qcExecution":{"$ref":"https://contracts.cellweave.dev/schemas/jobs/qc-execution.v1.json#/$defs/QcPreparedExecution"}},"additionalProperties":false},"ComputeJobStatusResponse":{"type":"object","required":["jobId","providerJobId","status","startedAt"],"properties":{"jobId":{"type":"string"},"providerJobId":{"type":"string"},"status":{"type":"string","enum":["PENDING","RUNNING","COMPLETED","FAILED","CANCELLED","TIMEOUT","UNKNOWN"]},"startedAt":{"type":"string","format":"date-time"},"completedAt":{"type":"string","format":"date-time"},"exitCode":{"type":"integer"},"errorMessage":{"type":"string"}},"additionalProperties":false},"ComputeJobCancelRequest":{"type":"object","required":["jobId","reason"],"properties":{"jobId":{"type":"string"},"providerJobId":{"type":"string"},"reason":{"type":"string"}},"additionalProperties":false},"ComputeJobResultResponse":{"type":"object","required":["jobId","providerJobId","status","metrics"],"properties":{"jobId":{"type":"string"},"providerJobId":{"type":"string"},"status":{"type":"string","enum":["COMPLETED","FAILED","CANCELLED"]},"resultUri":{"type":"string"},"metrics":{"type":"object","required":["cpuSeconds","memoryMegabyteSeconds"],"properties":{"cpuSeconds":{"type":"number","minimum":0},"gpuSeconds":{"type":"number","minimum":0,"default":0},"memoryMegabyteSeconds":{"type":"number","minimum":0},"peakMemoryBytes":{"type":"integer","minimum":0}},"additionalProperties":false},"error":{"$ref":"https://contracts.cellweave.dev/schemas/domain/domain-error.v1.json"},"executionResult":{"$ref":"https://contracts.cellweave.dev/schemas/jobs/workflow-execution.v1.json#/$defs/ExecutionResult"},"qcResult":{"$ref":"https://contracts.cellweave.dev/schemas/jobs/qc-execution.v1.json#/$defs/QcJobResult"}},"additionalProperties":false}}},{"$schema":"https://json-schema.org/draft/2020-12/schema","$id":"https://contracts.cellweave.dev/schemas/domain/account-state.v1.json","title":"AccountState","description":"Lifecycle and payment recovery states for an organization billing account.","type":"string","enum":["ACTIVE","PAST_DUE","SUSPENDED","CLOSING","DELETED"]},{"$schema":"https://json-schema.org/draft/2020-12/schema","$id":"https://contracts.cellweave.dev/schemas/domain/domain-error.v1.json","title":"DomainError","description":"Standardized domain error structure crossing service and API boundaries.","type":"object","required":["code","message","technicalDetail","recommendedAction","correlationId"],"properties":{"code":{"type":"string","description":"Machine-readable domain error code (e.g. SCIENTIFIC_VALIDATION_ERROR, PLATFORM_ERROR)."},"message":{"type":"string","description":"User-facing, safe description of the error."},"technicalDetail":{"type":"string","description":"Diagnostic context for bioinformatics or engineering staff, excluding PHI and raw scientific matrices."},"recommendedAction":{"type":"string","description":"Actionable guidance for the user or operator to resolve the error."},"correlationId":{"type":"string","description":"Unique request or run trace correlation ID for support diagnostics."},"retryable":{"type":"boolean","description":"Whether the operation may be retried without parameter alteration.","default":false},"details":{"type":"object","description":"Optional structured error details and parameter violations.","additionalProperties":true}},"additionalProperties":false},{"$schema":"https://json-schema.org/draft/2020-12/schema","$id":"https://contracts.cellweave.dev/schemas/domain/gene-id-scheme.v1.json","title":"GeneIdScheme","description":"Gene identifier scheme enum supported by CellWeave scientific pipelines.","type":"string","enum":["ENSEMBL","SYMBOL"]},{"$schema":"https://json-schema.org/draft/2020-12/schema","$id":"https://contracts.cellweave.dev/schemas/domain/import-file-role.v1.json","title":"ImportFileRole","description":"Functional scientific role assigned to a participating dataset file in an import manifest.","type":"string","enum":["PRIMARY","MATRIX","FEATURES","BARCODES","CELL_METADATA","FEATURE_METADATA"]},{"$schema":"https://json-schema.org/draft/2020-12/schema","$id":"https://contracts.cellweave.dev/schemas/domain/import-inspection-result.v1.json","title":"ImportInspectionResult","description":"Scientific inspection result describing dataset dimensions, metadata readiness, and issues.","type":"object","required":["datasetVersionId","sourceFormat","status","requiresMapping","availableCellMetadataColumns","availableFeatureMetadataColumns","issues"],"properties":{"datasetVersionId":{"type":"string","description":"Canonical dataset version ID (dsv_...)."},"sourceFormat":{"$ref":"https://contracts.cellweave.dev/schemas/domain/source-format.v1.json","description":"Inspected source format."},"status":{"$ref":"https://contracts.cellweave.dev/schemas/domain/inspection-status.v1.json","description":"Overall inspection readiness status."},"cellCountEstimate":{"type":["integer","null"],"minimum":0,"description":"Estimated cell count without full dataset load."},"geneCountEstimate":{"type":["integer","null"],"minimum":0,"description":"Estimated gene count without full dataset load."},"detectedOrganism":{"anyOf":[{"$ref":"https://contracts.cellweave.dev/schemas/domain/organism.v1.json"},{"type":"null"}],"description":"Heuristically detected organism taxonomy or null if unresolved."},"detectedGeneIdScheme":{"anyOf":[{"$ref":"https://contracts.cellweave.dev/schemas/domain/gene-id-scheme.v1.json"},{"type":"null"}],"description":"Heuristically detected gene ID scheme or null if unresolved."},"referenceBuildCandidate":{"type":["string","null"],"description":"Candidate genomic reference build if identified in metadata."},"requiresMapping":{"type":"boolean","description":"Whether user confirmation via the Metadata Wizard is required."},"availableCellMetadataColumns":{"type":"array","items":{"type":"string"},"description":"List of available cell/observation metadata columns observed in source files."},"availableFeatureMetadataColumns":{"type":"array","items":{"type":"string"},"description":"List of available feature/gene metadata columns observed in source files."},"issues":{"type":"array","items":{"$ref":"https://contracts.cellweave.dev/schemas/domain/scientific-issue.v1.json"},"description":"List of structured scientific warnings, errors, or prompts."}},"additionalProperties":false},{"$schema":"https://json-schema.org/draft/2020-12/schema","$id":"https://contracts.cellweave.dev/schemas/domain/inspection-status.v1.json","title":"InspectionStatus","description":"Readiness and mapping status resulting from dataset source inspection.","type":"string","enum":["VALID","NEEDS_MAPPING","INVALID"]},{"$schema":"https://json-schema.org/draft/2020-12/schema","$id":"https://contracts.cellweave.dev/schemas/domain/matrix-orientation.v1.json","title":"MatrixOrientation","description":"Orientation of rows and columns in generic tabular or matrix expression data.","type":"string","enum":["CELLS_BY_GENES","GENES_BY_CELLS"]},{"$schema":"https://json-schema.org/draft/2020-12/schema","$id":"https://contracts.cellweave.dev/schemas/domain/metadata-mapping-submission.v1.json","title":"MetadataMappingSubmission","description":"User-confirmed metadata mapping submission from the Metadata Wizard. Format-specific: generic matrices require column selections, while H5AD/10x rely on canonical slots.","type":"object","required":["datasetVersionId","organism","geneIdScheme"],"properties":{"datasetVersionId":{"type":"string","description":"Canonical dataset version ID (dsv_...)."},"organism":{"$ref":"https://contracts.cellweave.dev/schemas/domain/organism.v1.json","description":"Confirmed organism taxonomy."},"geneIdScheme":{"$ref":"https://contracts.cellweave.dev/schemas/domain/gene-id-scheme.v1.json","description":"Confirmed gene identifier scheme."},"referenceBuild":{"type":["string","null"],"description":"Optional user-confirmed genomic reference build."},"orientation":{"$ref":"https://contracts.cellweave.dev/schemas/domain/matrix-orientation.v1.json","description":"Confirmed orientation for generic matrix inputs."},"cellIdColumn":{"type":["string","null"],"description":"Authoritative canonical cell identifier column in supplied CELL_METADATA. May equal cellMetadataJoinColumn or translate source tokens into canonical cell IDs; never implies sample identity."},"geneIdColumn":{"type":["string","null"],"description":"Canonical/stable feature identifier column used for canonical var_names when FEATURE_METADATA supplies it (distinct from featureMetadataJoinColumn)."},"geneSymbolColumn":{"type":["string","null"],"description":"Descriptive gene symbol column only (var['gene_symbol'])."},"matrixCellIdColumn":{"type":["string","null"],"description":"Explicit column in a CSV/TSV MATRIX file containing source cell-axis identifiers when cells are represented by matrix rows (CELLS_BY_GENES)."},"matrixFeatureIdColumn":{"type":["string","null"],"description":"Explicit column in a CSV/TSV MATRIX file containing source feature-axis identifiers when features are represented by matrix rows (GENES_BY_CELLS)."},"cellMetadataJoinColumn":{"type":["string","null"],"description":"Column in CELL_METADATA containing source cell tokens used to join metadata to matrix cell identity."},"featureMetadataJoinColumn":{"type":["string","null"],"description":"Column in FEATURE_METADATA containing source feature tokens used to join metadata to matrix feature identity (source_feature_id)."},"cellAxisIndexColumn":{"type":["string","null"],"description":"Column in CELL_METADATA containing the explicit 1-based integer Generic MTX cell-axis coordinate (1..n_cells)."},"featureAxisIndexColumn":{"type":["string","null"],"description":"Column in FEATURE_METADATA containing the explicit 1-based integer Generic MTX feature-axis coordinate (1..n_features)."},"sampleColumn":{"type":["string","null"],"description":"Column representing sample groupings in metadata."},"conditionColumn":{"type":["string","null"],"description":"Column representing experimental condition or disease state in metadata."},"batchColumn":{"type":["string","null"],"description":"Column representing sequencing batch or library run in metadata."},"biologicalReplicateColumn":{"type":["string","null"],"description":"Column representing biological replicate identifiers in metadata."},"technicalReplicateColumn":{"type":["string","null"],"description":"Column representing technical replicate identifiers in metadata."},"sampleMappings":{"type":"array","items":{"$ref":"https://contracts.cellweave.dev/schemas/domain/sample-mapping-entry.v1.json"},"description":"Explicit sample value to registered sample_key mappings."}},"additionalProperties":false},{"$schema":"https://json-schema.org/draft/2020-12/schema","$id":"https://contracts.cellweave.dev/schemas/domain/organism.v1.json","title":"Organism","description":"Taxonomic organism enum supported by CellWeave scientific pipelines.","type":"string","enum":["HUMAN","MOUSE"]},{"$schema":"https://json-schema.org/draft/2020-12/schema","$id":"https://contracts.cellweave.dev/schemas/domain/resource-class.v1.json","title":"ResourceClass","description":"Standard compute resource profile classes for scientific workload dispatch.","type":"string","enum":["CPU_SMALL","CPU_MEMORY","CPU_HIGH_MEMORY","GPU_SMALL","GPU_LARGE"]},{"$schema":"https://json-schema.org/draft/2020-12/schema","$id":"https://contracts.cellweave.dev/schemas/domain/run-state.v1.json","title":"RunState","description":"Lifecycle states for a CellWeave scientific analysis run.","type":"string","enum":["DRAFT","UPLOADING","START_PENDING","VALIDATING","QC_RUNNING","QC_REVIEW_REQUIRED","QUEUED","RUNNING","PAUSED_QUOTA","CANCEL_REQUESTED","CANCELLED","SUCCEEDED","FAILED"],"x-phase4-transitions":{"DRAFT":["UPLOADING","START_PENDING","CANCEL_REQUESTED"],"UPLOADING":["START_PENDING","FAILED","CANCEL_REQUESTED"],"START_PENDING":["QUEUED","FAILED","CANCEL_REQUESTED"],"QUEUED":["VALIDATING","RUNNING","FAILED","CANCEL_REQUESTED"],"VALIDATING":["RUNNING","FAILED","CANCEL_REQUESTED"],"RUNNING":["SUCCEEDED","FAILED","PAUSED_QUOTA","CANCEL_REQUESTED","QC_RUNNING"],"PAUSED_QUOTA":["QUEUED","FAILED","CANCEL_REQUESTED"],"CANCEL_REQUESTED":["CANCELLED","FAILED"],"QC_RUNNING":["QC_REVIEW_REQUIRED","FAILED","CANCEL_REQUESTED"],"QC_REVIEW_REQUIRED":["QUEUED","FAILED","CANCEL_REQUESTED"],"CANCELLED":[],"SUCCEEDED":[],"FAILED":[]}},{"$schema":"https://json-schema.org/draft/2020-12/schema","$id":"https://contracts.cellweave.dev/schemas/domain/sample-mapping-entry.v1.json","title":"SampleMappingEntry","description":"Mapping from an observed source sample value to an existing authorized CellWeave sampleKey. Does not create samples implicitly.","type":"object","required":["sourceValue","sampleKey"],"properties":{"sourceValue":{"type":"string","description":"Unique sample identifier string found in source file metadata."},"sampleKey":{"type":"string","description":"Target authorized sample_key registered in the PostgreSQL samples table. Must be an existing authorized sampleKey, not a client-created sample identifier."}},"additionalProperties":false},{"$schema":"https://json-schema.org/draft/2020-12/schema","$id":"https://contracts.cellweave.dev/schemas/domain/scientific-issue.v1.json","title":"ScientificIssue","description":"Structured scientific validation or inspection issue with machine-readable code.","type":"object","required":["code","severity","message","userActionRequired"],"properties":{"code":{"type":"string","description":"Stable machine-readable issue code.","enum":["UNSUPPORTED_FORMAT","FORMAT_MISMATCH","MALFORMED_INPUT","MISSING_COMPONENT","INVALID_IMPORT_CARDINALITY","DIMENSION_MISMATCH","DUPLICATE_CELL_IDS","AMBIGUOUS_GENE_IDENTIFIERS","AMBIGUOUS_ORIENTATION","MISSING_REQUIRED_METADATA","UNRESOLVED_SPECIES","UNSUPPORTED_SPECIES","UNSUPPORTED_MODALITY","NON_COUNT_INPUT","AMBIGUOUS_COUNT_SEMANTICS","RESOURCE_LIMIT","SECURITY_REJECTED","CANONICALIZATION_FAILED"]},"severity":{"type":"string","description":"Severity classification of the scientific issue.","enum":["ERROR","WARNING","REQUIRES_USER_INPUT"]},"message":{"type":"string","description":"Human-readable explanation of the issue."},"field":{"type":"string","description":"Optional affected field, column, or file path."},"userActionRequired":{"type":"boolean","description":"Whether human resolution is required before import or canonicalization can proceed."}},"additionalProperties":false},{"$schema":"https://json-schema.org/draft/2020-12/schema","$id":"https://contracts.cellweave.dev/schemas/domain/service-environment.v1.json","title":"ServiceEnvironment","description":"Internal service authentication vocabulary. No credential material.","type":"string","enum":["local","development","staging","production"]},{"$schema":"https://json-schema.org/draft/2020-12/schema","$id":"https://contracts.cellweave.dev/schemas/domain/service-scope.v1.json","title":"ServiceScope","description":"Internal service authentication vocabulary. No credential material.","type":"string","enum":["execution.prepare","execution.project","execution.finalize","execution.cancel","capability.issue"]},{"$schema":"https://json-schema.org/draft/2020-12/schema","$id":"https://contracts.cellweave.dev/schemas/domain/source-format.v1.json","title":"SourceFormat","description":"Authoritative scientific input dataset source format enum for Phase 3 import system.","type":"string","enum":["H5AD","TENX_H5","TENX_MTX","GENERIC_MATRIX"]},{"$schema":"https://json-schema.org/draft/2020-12/schema","$id":"https://contracts.cellweave.dev/schemas/domain/upload-state.v1.json","title":"UploadState","description":"Lifecycle and terminal states for a dataset upload session.","type":"string","enum":["CREATED","UPLOADING","UPLOADED","VERIFYING","VERIFIED","IMPORTED","FAILED","ABORTED","EXPIRED","QUARANTINED"]},{"$schema":"https://json-schema.org/draft/2020-12/schema","$id":"https://contracts.cellweave.dev/schemas/domain/workflow-step-state.v1.json","title":"WorkflowStepState","description":"Lifecycle states for an individual workflow step in Temporal execution.","type":"string","enum":["PENDING","QUEUED","RUNNING","SUCCEEDED","RETRYING","FAILED","SKIPPED","CANCELLED"],"x-phase4-transitions":{"PENDING":["QUEUED","CANCELLED","SKIPPED"],"QUEUED":["RUNNING","CANCELLED","FAILED"],"RUNNING":["SUCCEEDED","FAILED","RETRYING","CANCELLED"],"RETRYING":["RUNNING","FAILED","CANCELLED"],"SUCCEEDED":[],"FAILED":[],"SKIPPED":[],"CANCELLED":[]}},{"$schema":"https://json-schema.org/draft/2020-12/schema","$id":"https://contracts.cellweave.dev/schemas/events/audit-event.v1.json","title":"AuditEvent","description":"Append-only tenant audit record documenting administrative, security, and scientific workflow actions.","type":"object","required":["schemaVersion","eventId","organizationId","actor","action","resourceType","resourceId","timestamp"],"properties":{"schemaVersion":{"type":"string","description":"Semantic version of the audit event schema.","pattern":"^1\\.[0-9]+\\.[0-9]+$"},"eventId":{"type":"string","description":"Unique audit event identifier (UUIDv7)."},"organizationId":{"type":"string","description":"Tenant organization ID."},"actor":{"type":"object","required":["actorId","actorType"],"properties":{"actorId":{"type":"string"},"actorType":{"type":"string","description":"Type of actor performing the action (e.g. user, system, service_worker)."},"ipHash":{"type":"string"},"userAgent":{"type":"string"}},"additionalProperties":false},"action":{"type":"string","description":"Domain action performed (e.g. project.create, run.start, qc.confirm_filtering, member.invite)."},"resourceType":{"type":"string","description":"Domain entity type affected (e.g. organization, project, dataset, run, comparison)."},"resourceId":{"type":"string","description":"Target entity ID."},"metadata":{"type":"object","description":"Structured operational context. Raw matrices, gene expression arrays, patient identifiers, and PHI are strictly forbidden.","additionalProperties":true},"timestamp":{"type":"string","format":"date-time"}},"additionalProperties":false},{"$schema":"https://json-schema.org/draft/2020-12/schema","$id":"https://contracts.cellweave.dev/schemas/events/polar-webhook.v1.json","title":"PolarWebhookReceipt","description":"CellWeave internal persisted webhook receipt envelope for Polar billing webhooks received at /api/webhooks/polar. Preserves provider-owned payload semantics while capturing receipt metadata for persistence, replay prevention, and deduplication.","type":"object","required":["schemaVersion","receiptId","externalEventId","eventType","receivedAt","payload"],"properties":{"schemaVersion":{"type":"string","description":"Internal semantic version of the persisted receipt envelope contract.","pattern":"^1\\.[0-9]+\\.[0-9]+$"},"receiptId":{"type":"string","description":"Internal unique identifier of the persisted webhook receipt (e.g. UUIDv7)."},"externalEventId":{"type":"string","description":"Provider-assigned unique external event identifier for idempotent deduplication and replay prevention."},"eventType":{"type":"string","description":"Provider-reported event type string (e.g. subscription.created, order.created)."},"signatureVerified":{"type":"boolean","description":"Whether the provider signature was verified against webhook secret.","default":true},"receivedAt":{"type":"string","format":"date-time","description":"ISO 8601 timestamp when the webhook was received and persisted."},"payload":{"type":"object","description":"Provider-owned external webhook payload. Semantics and properties are strictly owned and versioned by Polar.","additionalProperties":true}},"additionalProperties":false},{"$schema":"https://json-schema.org/draft/2020-12/schema","$id":"https://contracts.cellweave.dev/schemas/events/service-event.v1.json","title":"ServiceEvent","description":"Standard cross-service event envelope for asynchronous pub/sub and state projections.","type":"object","required":["schemaVersion","eventId","eventType","source","correlationId","data","timestamp"],"properties":{"schemaVersion":{"type":"string","description":"Semantic version of the service event schema.","pattern":"^1\\.[0-9]+\\.[0-9]+$"},"eventId":{"type":"string"},"eventType":{"type":"string"},"source":{"type":"string"},"correlationId":{"type":"string"},"organizationId":{"type":"string"},"data":{"type":"object","additionalProperties":true},"timestamp":{"type":"string","format":"date-time"}},"additionalProperties":false},{"$schema":"https://json-schema.org/draft/2020-12/schema","$id":"https://contracts.cellweave.dev/schemas/events/usage-event.v1.json","title":"UsageEvent","description":"Immutable usage ledger event emitted upon completion of a billable workflow step.","type":"object","required":["schemaVersion","idempotencyKey","organizationId","projectId","runId","stepId","attempt","measurements","timestamp"],"properties":{"schemaVersion":{"type":"string","description":"Schema version of the usage event contract.","pattern":"^1\\.[0-9]+\\.[0-9]+$"},"idempotencyKey":{"type":"string","description":"Deterministic idempotency key structured as runId:stepId:attempt.","pattern":"^.+:.+:[0-9]+$"},"organizationId":{"type":"string","description":"Tenant organization ID owning the billing responsibility."},"projectId":{"type":"string","description":"Project ID under which the analysis executed."},"runId":{"type":"string","description":"Analysis run ID."},"stepId":{"type":"string","description":"Workflow step ID."},"attempt":{"type":"integer","minimum":1,"description":"Execution attempt index."},"measurements":{"type":"object","required":["cpuSeconds"],"properties":{"cpuSeconds":{"type":"number","minimum":0},"gpuSeconds":{"type":"number","minimum":0,"default":0},"memoryClass":{"$ref":"https://contracts.cellweave.dev/schemas/domain/resource-class.v1.json"},"bytesProcessed":{"type":"integer","minimum":0},"storageByteHours":{"type":"number","minimum":0},"egressBytes":{"type":"integer","minimum":0}},"additionalProperties":false},"timestamp":{"type":"string","format":"date-time","description":"ISO 8601 recording timestamp."}},"additionalProperties":false},{"$schema":"https://json-schema.org/draft/2020-12/schema","$id":"https://contracts.cellweave.dev/schemas/jobs/canonical-artifact-publication-capabilities.v1.json","title":"CanonicalArtifactPublicationCapabilities","description":"INTERNAL TRUSTED WORKER/CONTROL-PLANE CONTRACT ONLY. Never accepted from browser/client input. Server-issued, short-lived, narrowly scoped HTTP capabilities for publishing and verifying a single deterministic canonical.h5ad artifact. putUrl and getUrl are ephemeral secret capabilities and MUST be redacted from logs and error messages.","type":"object","required":["datasetVersionId","putUrl","getUrl","expiresAt","requiredPutHeaders","requiredGetHeaders"],"properties":{"datasetVersionId":{"type":"string","minLength":1,"description":"Canonical dataset version ID (dsv_...) for job correlation only. Does NOT authorize or determine storage destination."},"putUrl":{"type":"string","format":"uri","minLength":1,"description":"Opaque server-issued presigned PUT URL scoped to the single deterministic canonical object (org/{orgId}/project/{projectId}/datasets/{datasetVersionId}/canonical/canonical.h5ad). Ephemeral secret capability; must never be logged unredacted."},"getUrl":{"type":"string","format":"uri","minLength":1,"description":"Opaque server-issued presigned GET URL scoped to the same deterministic canonical object for existing-object reconciliation, remote byte streaming, and exact SHA-256 verification. Ephemeral secret capability; must never be logged unredacted."},"expiresAt":{"type":"string","format":"date-time","pattern":"^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}(?:\\.\\d+)?Z$","description":"Explicit UTC expiration timestamp (ISO 8601 ending in Z) for the issued capabilities. Science must fail controlled if expired before use and never auto-refresh credentials."},"requiredPutHeaders":{"type":"object","description":"Server-approved HTTP request headers bound to the signed PUT capability, including atomic create-once conditional header 'If-None-Match': '*' so a caller cannot convert the request into an overwrite.","required":["If-None-Match"],"properties":{"If-None-Match":{"type":"string","const":"*","description":"Mandatory conditional create-once header bound to the PUT capability to prevent overwriting an existing canonical object."}},"propertyNames":{"pattern":"^[A-Za-z0-9-]+$"},"additionalProperties":{"type":"string","minLength":1}},"requiredGetHeaders":{"type":"object","description":"Server-approved HTTP request headers bound to the signed GET capability if required by the presigner, or an empty object.","propertyNames":{"pattern":"^[A-Za-z0-9-]+$"},"additionalProperties":{"type":"string","minLength":1}}},"additionalProperties":false},{"$schema":"https://json-schema.org/draft/2020-12/schema","$id":"https://contracts.cellweave.dev/schemas/jobs/canonical-artifact-publication-result.v1.json","title":"CanonicalArtifactPublicationResult","description":"INTERNAL TRUSTED WORKER/CONTROL-PLANE CONTRACT ONLY. Result returned by the scientific runtime after publishing and verifying the immutable canonical.h5ad artifact via scoped capabilities. Integrity conflicts are represented as failures/errors, never as a success status. Does not include caller-authoritative canonicalArtifactKey.","type":"object","required":["datasetVersionId","canonicalChecksum","byteSize","status"],"properties":{"datasetVersionId":{"type":"string","minLength":1,"description":"Canonical dataset version ID (dsv_...) correlated with the publication attempt."},"canonicalChecksum":{"type":"string","pattern":"^[a-f0-9]{64}$","description":"Exact lowercase 64-character hexadecimal SHA-256 digest computed by the scientific engine over the local canonical.h5ad bytes and verified against remote object storage."},"byteSize":{"type":"integer","minimum":0,"description":"Exact byte size of the local canonical.h5ad artifact verified against the remote published object."},"status":{"type":"string","enum":["PUBLISHED","ALREADY_PRESENT"],"description":"Outcome of the immutable publication attempt. Integrity or content conflicts must fail as errors rather than returning a success status."}},"additionalProperties":false},{"$schema":"https://json-schema.org/draft/2020-12/schema","$id":"https://contracts.cellweave.dev/schemas/jobs/canonicalization-request.v1.json","title":"CanonicalizationRequest","description":"Scientific engine job request to canonicalize an immutable import manifest into canonical.h5ad.","type":"object","required":["datasetVersionId","importId","sourceFormat","sourceFiles","organism","geneIdScheme"],"properties":{"datasetVersionId":{"type":"string","description":"Canonical dataset version ID (dsv_...)."},"importId":{"type":"string","description":"Unique identifier of the registered import manifest (imp_...)."},"sourceFormat":{"$ref":"https://contracts.cellweave.dev/schemas/domain/source-format.v1.json","description":"Validated source format."},"sourceFiles":{"type":"array","minItems":1,"items":{"type":"object","required":["datasetFileId","role","ordinal","localPath"],"properties":{"datasetFileId":{"type":"string","description":"Canonical dataset file ID."},"role":{"$ref":"https://contracts.cellweave.dev/schemas/domain/import-file-role.v1.json","description":"Assigned role."},"ordinal":{"type":"integer","minimum":0,"description":"Role ordinal."},"localPath":{"type":"string","description":"Trusted local filesystem path to the verified source file."}},"additionalProperties":false}},"organism":{"$ref":"https://contracts.cellweave.dev/schemas/domain/organism.v1.json","description":"Confirmed organism taxonomy."},"geneIdScheme":{"$ref":"https://contracts.cellweave.dev/schemas/domain/gene-id-scheme.v1.json","description":"Confirmed gene identifier scheme."},"referenceBuild":{"type":["string","null"],"description":"Optional confirmed reference build."},"mapping":{"anyOf":[{"$ref":"https://contracts.cellweave.dev/schemas/domain/metadata-mapping-submission.v1.json"},{"type":"null"}],"description":"Optional confirmed metadata mapping submission."}},"additionalProperties":false},{"$schema":"https://json-schema.org/draft/2020-12/schema","$id":"https://contracts.cellweave.dev/schemas/jobs/canonicalization-result.v1.json","title":"CanonicalizationResult","description":"Scientific engine result produced by converting source files into canonical AnnData.","type":"object","required":["sourceFormat","canonicalFormat","canonicalChecksum","organism","geneIdScheme","cellCount","geneCount","warnings"],"properties":{"sourceFormat":{"$ref":"https://contracts.cellweave.dev/schemas/domain/source-format.v1.json","description":"Original source format."},"canonicalFormat":{"type":"string","enum":["H5AD"],"description":"Canonical format of the serialized dataset."},"canonicalChecksum":{"type":"string","pattern":"^[a-f0-9]{64}$","description":"SHA-256 hex digest of the canonical.h5ad artifact."},"organism":{"$ref":"https://contracts.cellweave.dev/schemas/domain/organism.v1.json","description":"Finalized organism taxonomy."},"geneIdScheme":{"$ref":"https://contracts.cellweave.dev/schemas/domain/gene-id-scheme.v1.json","description":"Finalized gene identifier scheme."},"referenceBuild":{"type":["string","null"],"description":"Finalized genomic reference build if known."},"cellCount":{"type":"integer","minimum":1,"description":"Final canonical cell count (N observations)."},"geneCount":{"type":"integer","minimum":1,"description":"Final canonical gene count (D variables)."},"warnings":{"type":"array","items":{"$ref":"https://contracts.cellweave.dev/schemas/domain/scientific-issue.v1.json"},"description":"Structured scientific warnings collected during canonicalization."},"localArtifactPath":{"type":["string","null"],"description":"Optional local filesystem path to the generated canonical.h5ad file."}},"additionalProperties":false},{"$schema":"https://json-schema.org/draft/2020-12/schema","$id":"https://contracts.cellweave.dev/schemas/jobs/qc-execution.v1.json","title":"QcExecutionContracts","description":"Versioned Phase 5 scientific, review and trusted execution boundaries. No storage credentials or browser scientific authority.","type":"object","additionalProperties":false,"$defs":{"QcIssue":{"type":"object","properties":{"code":{"type":"string","enum":["ZERO_COUNT_PERCENTAGE_UNAVAILABLE","GENE_SYMBOLS_REQUIRED_FOR_QC_GENE_SET","SAMPLE_ASSIGNMENT_UNAVAILABLE","CAPTURE_GROUP_UNRESOLVED","INSUFFICIENT_CELLS","INSUFFICIENT_FEATURES","DEGENERATE_DATA","THRESHOLD_INFERENCE_FAILED","SCRUBLET_FAILED"]},"groupKey":{"anyOf":[{"type":"string","minLength":1,"maxLength":200},{"type":"null"}]},"affectedCells":{"type":"integer","minimum":0}},"required":["code","groupKey","affectedCells"],"additionalProperties":false},"QcSampleBinding":{"type":"object","properties":{"sampleId":{"type":"string","minLength":1,"maxLength":200},"sampleKey":{"type":"string","minLength":1,"maxLength":200},"captureGroupKey":{"anyOf":[{"type":"string","minLength":1,"maxLength":200},{"type":"null"}]},"expectedDoubletRate":{"anyOf":[{"type":"number","exclusiveMinimum":0,"exclusiveMaximum":1},{"type":"null"}]}},"required":["sampleId","sampleKey","captureGroupKey","expectedDoubletRate"],"additionalProperties":false},"QcAnalysisParameters":{"type":"object","properties":{"geneSetPolicy":{"type":"string","enum":["cellweave-symbol-prefixes-v1"]},"scrubletProfile":{"type":"string","enum":["cellweave-scanpy-scrublet-v1"]},"randomSeed":{"type":"integer","minimum":0,"maximum":2147483647},"samples":{"type":"array","items":{"$ref":"#/$defs/QcSampleBinding"},"maxItems":1000},"wholeInputSampleId":{"anyOf":[{"type":"string","minLength":1,"maxLength":200},{"type":"null"}]}},"required":["geneSetPolicy","scrubletProfile","randomSeed","samples","wholeInputSampleId"],"additionalProperties":false},"QcCaptureRequest":{"type":"object","properties":{"sampleId":{"type":"string","minLength":1,"maxLength":200},"captureGroupKey":{"type":"string","minLength":1,"maxLength":200}},"required":["sampleId","captureGroupKey"],"additionalProperties":false},"QcStartRequest":{"type":"object","properties":{"datasetVersionId":{"type":"string","minLength":1,"maxLength":200},"captureBindings":{"type":"array","items":{"$ref":"#/$defs/QcCaptureRequest"},"maxItems":1000},"wholeInputSampleId":{"anyOf":[{"type":"string","minLength":1,"maxLength":200},{"type":"null"}]}},"required":["datasetVersionId","captureBindings","wholeInputSampleId"],"additionalProperties":false},"QcThresholdRule":{"type":"object","properties":{"metric":{"type":"string","enum":["total_counts","n_genes_by_counts","total_counts_mt","pct_counts_mt","total_counts_ribo","pct_counts_ribo"]},"minimum":{"anyOf":[{"type":"number","minimum":0},{"type":"null"}]},"maximum":{"anyOf":[{"type":"number","minimum":0},{"type":"null"}]},"sampleKey":{"anyOf":[{"type":"string","minLength":1,"maxLength":200},{"type":"null"}]}},"required":["metric","minimum","maximum","sampleKey"],"additionalProperties":false},"QcSelectionParameters":{"type":"object","properties":{"thresholds":{"type":"array","items":{"$ref":"#/$defs/QcThresholdRule"},"maxItems":1000},"doubletHandling":{"type":"string","enum":["RETAIN","EXCLUDE_PREDICTED"]}},"required":["thresholds","doubletHandling"],"additionalProperties":false},"QcApprovalRequest":{"type":"object","properties":{"previewId":{"type":"string","minLength":1,"maxLength":200},"reason":{"type":"string","minLength":1,"maxLength":1000}},"required":["previewId","reason"],"additionalProperties":false},"QcHistogramBin":{"type":"object","properties":{"lower":{"type":"number"},"upper":{"type":"number"},"count":{"type":"integer","minimum":0}},"required":["lower","upper","count"],"additionalProperties":false},"QcMetricSummary":{"type":"object","properties":{"metric":{"type":"string","enum":["total_counts","n_genes_by_counts","total_counts_mt","pct_counts_mt","total_counts_ribo","pct_counts_ribo"]},"availableCells":{"type":"integer","minimum":0},"minimum":{"anyOf":[{"type":"number"},{"type":"null"}]},"maximum":{"anyOf":[{"type":"number"},{"type":"null"}]},"mean":{"anyOf":[{"type":"number"},{"type":"null"}]},"histogram":{"type":"array","items":{"$ref":"#/$defs/QcHistogramBin"},"maxItems":20}},"required":["metric","availableCells","minimum","maximum","mean","histogram"],"additionalProperties":false},"QcSampleSummary":{"type":"object","properties":{"sampleId":{"type":"string","minLength":1,"maxLength":200},"sampleKey":{"type":"string","minLength":1,"maxLength":200},"cellCount":{"type":"integer","minimum":0},"metrics":{"type":"array","items":{"$ref":"#/$defs/QcMetricSummary"},"maxItems":6}},"required":["sampleId","sampleKey","cellCount","metrics"],"additionalProperties":false},"QcSoftwareVersion":{"type":"object","properties":{"name":{"type":"string","minLength":1,"maxLength":200},"version":{"type":"string","minLength":1,"maxLength":200}},"required":["name","version"],"additionalProperties":false},"QcParameterValue":{"type":"object","properties":{"name":{"type":"string","minLength":1,"maxLength":200},"value":{"type":"string","maxLength":1000}},"required":["name","value"],"additionalProperties":false},"QcDoubletAssessment":{"type":"object","properties":{"captureGroupKey":{"type":"string","minLength":1,"maxLength":200},"status":{"type":"string","enum":["ASSESSED","NOT_ASSESSED"]},"reason":{"anyOf":[{"type":"string","maxLength":100},{"type":"null"}]},"cellCount":{"type":"integer","minimum":0},"threshold":{"anyOf":[{"type":"number"},{"type":"null"}]},"predictedCount":{"anyOf":[{"type":"integer","minimum":0},{"type":"null"}]},"parameters":{"type":"array","items":{"$ref":"#/$defs/QcParameterValue"},"maxItems":40}},"required":["captureGroupKey","status","reason","cellCount","threshold","predictedCount","parameters"],"additionalProperties":false},"QcSummary":{"type":"object","properties":{"schemaVersion":{"type":"string","enum":["1.0.0"]},"geneSetPolicy":{"type":"string","enum":["cellweave-symbol-prefixes-v1"]},"scrubletProfile":{"type":"string","enum":["cellweave-scanpy-scrublet-v1"]},"randomSeed":{"type":"integer","minimum":0},"cellCount":{"type":"integer","minimum":1},"geneCount":{"type":"integer","minimum":1},"metrics":{"type":"array","items":{"$ref":"#/$defs/QcMetricSummary"},"maxItems":6},"samples":{"type":"array","items":{"$ref":"#/$defs/QcSampleSummary"},"maxItems":1000},"sampleQcAvailable":{"type":"boolean"},"doublets":{"type":"array","items":{"$ref":"#/$defs/QcDoubletAssessment"},"maxItems":1000},"issues":{"type":"array","items":{"$ref":"#/$defs/QcIssue"},"maxItems":3000},"software":{"type":"array","items":{"$ref":"#/$defs/QcSoftwareVersion"},"maxItems":20},"suggestions":{"type":"array","items":{"$ref":"#/$defs/QcThresholdRule"},"maxItems":0}},"required":["schemaVersion","geneSetPolicy","scrubletProfile","randomSeed","cellCount","geneCount","metrics","samples","sampleQcAvailable","doublets","issues","software","suggestions"],"additionalProperties":false},"QcArtifactTarget":{"type":"object","properties":{"artifactId":{"type":"string","minLength":1,"maxLength":200},"type":{"type":"string","enum":["QC_REPORT","FILTERED_DATASET"]},"fileName":{"type":"string","enum":["qc_metrics.jsonl.gz","qc_summary.json","selection.jsonl.gz","filtered.h5ad"]},"putUrl":{"type":"string","format":"uri"},"getUrl":{"type":"string","format":"uri"},"expiresAt":{"type":"string","format":"date-time"},"ifNoneMatch":{"type":"string","enum":["*"]}},"required":["artifactId","type","fileName","putUrl","getUrl","expiresAt","ifNoneMatch"],"additionalProperties":false},"QcArtifactInput":{"type":"object","properties":{"artifactId":{"type":"string","minLength":1,"maxLength":200},"type":{"type":"string","enum":["CANONICAL_DATASET","QC_REPORT"]},"sha256":{"type":"string","pattern":"^[a-f0-9]{64}$"},"byteSize":{"type":"integer","minimum":0,"maximum":9007199254740991},"downloadUrl":{"type":"string","format":"uri"}},"required":["artifactId","type","sha256","byteSize","downloadUrl"],"additionalProperties":false},"QcFilterBinding":{"type":"object","properties":{"decisionId":{"type":"string","minLength":1,"maxLength":200},"canonicalChecksum":{"type":"string","pattern":"^[a-f0-9]{64}$"},"selectionArtifactId":{"type":"string","minLength":1,"maxLength":200},"selectionChecksum":{"type":"string","pattern":"^[a-f0-9]{64}$"},"parametersChecksum":{"type":"string","pattern":"^[a-f0-9]{64}$"},"includedCount":{"type":"integer","minimum":1},"excludedCount":{"type":"integer","minimum":0}},"required":["decisionId","canonicalChecksum","selectionArtifactId","selectionChecksum","parametersChecksum","includedCount","excludedCount"],"additionalProperties":false},"QcPreparedExecution":{"type":"object","properties":{"schemaVersion":{"type":"string","enum":["1.0.0"]},"environment":{"$ref":"https://contracts.cellweave.dev/schemas/domain/service-environment.v1.json"},"analysisRunId":{"type":"string","minLength":1,"maxLength":200},"stepId":{"type":"string","minLength":1,"maxLength":200},"submissionId":{"type":"string","minLength":1,"maxLength":200},"pipelineVersion":{"type":"string","minLength":1,"maxLength":200},"operation":{"type":"string","enum":["QC","PREVIEW","FILTER"]},"qcRevision":{"type":"integer","minimum":1},"deadlineAt":{"type":"string","format":"date-time"},"ceilings":{"$ref":"https://contracts.cellweave.dev/schemas/jobs/workflow-execution.v1.json#/$defs/ExecutionCeilings"},"canonical":{"$ref":"#/$defs/QcArtifactInput"},"auxiliary":{"type":"array","items":{"$ref":"#/$defs/QcArtifactInput"},"maxItems":2},"targets":{"type":"array","items":{"$ref":"#/$defs/QcArtifactTarget"},"maxItems":2},"analysis":{"$ref":"#/$defs/QcAnalysisParameters"},"selection":{"anyOf":[{"$ref":"#/$defs/QcSelectionParameters"},{"type":"null"}]},"decision":{"anyOf":[{"$ref":"#/$defs/QcFilterBinding"},{"type":"null"}]}},"required":["schemaVersion","environment","analysisRunId","stepId","submissionId","pipelineVersion","operation","qcRevision","deadlineAt","ceilings","canonical","auxiliary","targets","analysis","selection","decision"],"additionalProperties":false},"QcProducedArtifact":{"type":"object","properties":{"artifactId":{"type":"string","minLength":1,"maxLength":200},"type":{"type":"string","enum":["QC_REPORT","FILTERED_DATASET"]},"fileName":{"type":"string","enum":["qc_metrics.jsonl.gz","qc_summary.json","selection.jsonl.gz","filtered.h5ad"]},"sha256":{"type":"string","pattern":"^[a-f0-9]{64}$"},"byteSize":{"type":"integer","minimum":0,"maximum":9007199254740991},"status":{"type":"string","enum":["PUBLISHED","ALREADY_PRESENT"]}},"required":["artifactId","type","fileName","sha256","byteSize","status"],"additionalProperties":false},"QcPreviewProof":{"type":"object","properties":{"previewId":{"type":"string","minLength":1,"maxLength":200},"qcRevision":{"type":"integer","minimum":1},"canonicalChecksum":{"type":"string","pattern":"^[a-f0-9]{64}$"},"parametersChecksum":{"type":"string","pattern":"^[a-f0-9]{64}$"},"selectionArtifactId":{"type":"string","minLength":1,"maxLength":200},"selectionChecksum":{"type":"string","pattern":"^[a-f0-9]{64}$"},"includedCount":{"type":"integer","minimum":1},"excludedCount":{"type":"integer","minimum":0}},"required":["previewId","qcRevision","canonicalChecksum","parametersChecksum","selectionArtifactId","selectionChecksum","includedCount","excludedCount"],"additionalProperties":false},"QcJobResult":{"type":"object","properties":{"analysisRunId":{"type":"string","minLength":1,"maxLength":200},"stepId":{"type":"string","minLength":1,"maxLength":200},"submissionId":{"type":"string","minLength":1,"maxLength":200},"operation":{"type":"string","enum":["QC","PREVIEW","FILTER"]},"artifacts":{"type":"array","items":{"$ref":"#/$defs/QcProducedArtifact"},"maxItems":2},"summary":{"anyOf":[{"$ref":"#/$defs/QcSummary"},{"type":"null"}]},"preview":{"anyOf":[{"$ref":"#/$defs/QcPreviewProof"},{"type":"null"}]}},"required":["analysisRunId","stepId","submissionId","operation","artifacts","summary","preview"],"additionalProperties":false},"QcDecision":{"type":"object","properties":{"schemaVersion":{"type":"string","enum":["1.0.0"]},"id":{"type":"string","minLength":1,"maxLength":200},"organizationId":{"type":"string","minLength":1,"maxLength":200},"projectId":{"type":"string","minLength":1,"maxLength":200},"analysisRunId":{"type":"string","minLength":1,"maxLength":200},"datasetVersionId":{"type":"string","minLength":1,"maxLength":200},"canonicalChecksum":{"type":"string","pattern":"^[a-f0-9]{64}$"},"qcRevision":{"type":"integer","minimum":1},"preview":{"$ref":"#/$defs/QcPreviewProof"},"selection":{"$ref":"#/$defs/QcSelectionParameters"},"actorId":{"type":"string","minLength":1,"maxLength":200},"createdAt":{"type":"string","format":"date-time"},"reason":{"type":"string","minLength":1,"maxLength":1000},"geneSetPolicy":{"type":"string","enum":["cellweave-symbol-prefixes-v1"]},"scrubletProfile":{"type":"string","enum":["cellweave-scanpy-scrublet-v1"]}},"required":["schemaVersion","id","organizationId","projectId","analysisRunId","datasetVersionId","canonicalChecksum","qcRevision","preview","selection","actorId","createdAt","reason","geneSetPolicy","scrubletProfile"],"additionalProperties":false},"QcApprovalSignal":{"type":"object","properties":{"schemaVersion":{"type":"string","enum":["1.0.0"]},"analysisRunId":{"type":"string","minLength":1,"maxLength":200},"decisionId":{"type":"string","minLength":1,"maxLength":200}},"required":["schemaVersion","analysisRunId","decisionId"],"additionalProperties":false},"QcStepContext":{"type":"object","properties":{"operation":{"type":"string","enum":["QC","PREVIEW","FILTER"]},"revision":{"type":"integer","minimum":1},"selection":{"anyOf":[{"$ref":"#/$defs/QcSelectionParameters"},{"type":"null"}]},"decisionId":{"anyOf":[{"type":"string","minLength":1,"maxLength":200},{"type":"null"}]},"outputIds":{"type":"array","items":{"type":"string","minLength":1,"maxLength":200},"maxItems":2},"deadlineAt":{"anyOf":[{"type":"string","format":"date-time"},{"type":"null"}]}},"required":["operation","revision","selection","decisionId","outputIds","deadlineAt"],"additionalProperties":false},"QcStepControl":{"type":"object","properties":{"stepId":{"type":"string","minLength":1,"maxLength":200},"submissionId":{"type":"string","minLength":1,"maxLength":200},"status":{"$ref":"https://contracts.cellweave.dev/schemas/domain/workflow-step-state.v1.json"},"providerJobId":{"anyOf":[{"type":"string","minLength":1,"maxLength":200},{"type":"null"}]},"providerState":{"type":"string","enum":["UNKNOWN","PENDING","RUNNING","COMPLETED","FAILED","CANCELLED","TIMEOUT"]},"context":{"$ref":"#/$defs/QcStepContext"},"result":{"anyOf":[{"$ref":"#/$defs/QcJobResult"},{"type":"null"}]}},"required":["stepId","submissionId","status","providerJobId","providerState","context","result"],"additionalProperties":false},"QcControl":{"type":"object","properties":{"analysisRunId":{"type":"string","minLength":1,"maxLength":200},"status":{"$ref":"https://contracts.cellweave.dev/schemas/domain/run-state.v1.json"},"projectionVersion":{"type":"integer","minimum":0},"cancelRequested":{"type":"boolean"},"filterCommitted":{"type":"boolean"},"qcRevision":{"type":"integer","minimum":1},"steps":{"type":"array","items":{"$ref":"#/$defs/QcStepControl"},"maxItems":1000},"decision":{"anyOf":[{"$ref":"#/$defs/QcDecision"},{"type":"null"}]},"approvalPending":{"type":"boolean"}},"required":["analysisRunId","status","projectionVersion","cancelRequested","filterCommitted","qcRevision","steps","decision","approvalPending"],"additionalProperties":false},"QcProjection":{"type":"object","properties":{"analysisRunId":{"type":"string","minLength":1,"maxLength":200},"sequence":{"type":"integer","minimum":1},"status":{"$ref":"https://contracts.cellweave.dev/schemas/domain/run-state.v1.json"}},"required":["analysisRunId","sequence","status"],"additionalProperties":false},"QcCellMetrics":{"type":"object","properties":{"cellId":{"type":"string"},"sampleId":{"anyOf":[{"type":"string"},{"type":"null"}]},"sampleKey":{"anyOf":[{"type":"string"},{"type":"null"}]},"captureGroupKey":{"anyOf":[{"type":"string"},{"type":"null"}]},"total_counts":{"type":"number"},"n_genes_by_counts":{"type":"integer","minimum":0},"total_counts_mt":{"anyOf":[{"type":"number"},{"type":"null"}]},"pct_counts_mt":{"anyOf":[{"type":"number"},{"type":"null"}]},"total_counts_ribo":{"anyOf":[{"type":"number"},{"type":"null"}]},"pct_counts_ribo":{"anyOf":[{"type":"number"},{"type":"null"}]},"doublet_score":{"anyOf":[{"type":"number"},{"type":"null"}]},"predicted_doublet":{"anyOf":[{"type":"boolean"},{"type":"null"}]}},"required":["cellId","sampleId","sampleKey","captureGroupKey","total_counts","n_genes_by_counts","total_counts_mt","pct_counts_mt","total_counts_ribo","pct_counts_ribo","doublet_score","predicted_doublet"],"additionalProperties":false},"QcSelectionHeader":{"type":"object","properties":{"schemaVersion":{"type":"string","const":"1.0.0"},"previewId":{"type":"string"},"qcRevision":{"type":"integer","minimum":0},"canonicalChecksum":{"type":"string","pattern":"^[a-f0-9]{64}$"},"parametersChecksum":{"type":"string","pattern":"^[a-f0-9]{64}$"},"cellOrderChecksum":{"type":"string","pattern":"^[a-f0-9]{64}$"},"includedCount":{"type":"integer","minimum":0},"excludedCount":{"type":"integer","minimum":0}},"required":["schemaVersion","previewId","qcRevision","canonicalChecksum","parametersChecksum","cellOrderChecksum","includedCount","excludedCount"],"additionalProperties":false},"QcSelectionRow":{"type":"object","properties":{"cellId":{"type":"string"},"included":{"type":"boolean"}},"required":["cellId","included"],"additionalProperties":false},"QcReviewView":{"type":"object","properties":{"analysisRunId":{"type":"string"},"datasetVersionId":{"type":"string"},"status":{"$ref":"https://contracts.cellweave.dev/schemas/domain/run-state.v1.json"},"qcRevision":{"type":"integer","minimum":1},"summary":{"anyOf":[{"$ref":"#/$defs/QcSummary"},{"type":"null"}]},"preview":{"anyOf":[{"$ref":"#/$defs/QcPreviewProof"},{"type":"null"}]},"previewPending":{"type":"boolean"},"previewError":{"anyOf":[{"type":"string","enum":["QC_SELECTION_REJECTED"]},{"type":"null"}]},"previewParameters":{"anyOf":[{"$ref":"#/$defs/QcSelectionParameters"},{"type":"null"}]},"decision":{"anyOf":[{"$ref":"#/$defs/QcDecision"},{"type":"null"}]},"canApprove":{"type":"boolean"},"filteredArtifactId":{"type":["string","null"]}},"required":["analysisRunId","datasetVersionId","status","qcRevision","summary","preview","previewPending","previewError","previewParameters","decision","canApprove","filteredArtifactId"],"additionalProperties":false},"QcSampleOption":{"type":"object","properties":{"sampleId":{"type":"string"},"sampleKey":{"type":"string"},"label":{"type":"string"}},"required":["sampleId","sampleKey","label"],"additionalProperties":false},"QcDatasetOption":{"type":"object","properties":{"datasetVersionId":{"type":"string"},"label":{"type":"string"},"samples":{"type":"array","items":{"$ref":"#/$defs/QcSampleOption"},"maxItems":1000}},"required":["datasetVersionId","label","samples"],"additionalProperties":false},"QcInputOptions":{"type":"object","properties":{"canStart":{"type":"boolean"},"datasets":{"type":"array","items":{"$ref":"#/$defs/QcDatasetOption"},"maxItems":100}},"required":["canStart","datasets"],"additionalProperties":false}}},{"$schema":"https://json-schema.org/draft/2020-12/schema","$id":"https://contracts.cellweave.dev/schemas/jobs/scientific-job.v1.json","title":"ScientificJobPayload","description":"Cross-boundary scientific job payload envelope sent from Temporal orchestrator to Python scientific compute worker.","type":"object","required":["schemaVersion","pipelineVersion","jobId","runId","stepId","jobType","inputs","outputs","parameters","manifestFragment"],"properties":{"schemaVersion":{"type":"string","description":"Semantic schema version of this job payload envelope.","pattern":"^1\\.[0-9]+\\.[0-9]+$"},"pipelineVersion":{"type":"string","description":"Pinned immutable pipeline version executing this step."},"jobId":{"type":"string","description":"Unique compute execution attempt ID."},"runId":{"type":"string","description":"Analysis run ID."},"stepId":{"type":"string","description":"Workflow step ID."},"jobType":{"type":"string","description":"Scientific logical task to execute.","enum":["validate_dataset","run_qc","filter_cells","normalize","select_hvg","run_pca","build_neighbors","run_umap","cluster","annotate","find_markers","run_differential_expression","run_pathway_analysis","generate_exports"]},"resourceClass":{"$ref":"https://contracts.cellweave.dev/schemas/domain/resource-class.v1.json"},"inputs":{"type":"object","description":"Scoped input capabilities containing presigned download URLs and checksums.","required":["primaryDataset"],"properties":{"primaryDataset":{"type":"object","required":["downloadUrl","sha256"],"properties":{"downloadUrl":{"type":"string","description":"Short-lived scoped signed read URL."},"sha256":{"type":"string","pattern":"^[a-f0-9]{64}$"},"format":{"type":"string"}},"additionalProperties":false},"auxiliaryInputs":{"type":"array","items":{"type":"object","required":["name","downloadUrl","sha256"],"properties":{"name":{"type":"string"},"downloadUrl":{"type":"string"},"sha256":{"type":"string","pattern":"^[a-f0-9]{64}$"}},"additionalProperties":false}}},"additionalProperties":false},"outputs":{"type":"object","description":"Scoped output capabilities providing presigned upload targets for generated artifacts.","required":["targets"],"properties":{"targets":{"type":"array","items":{"type":"object","required":["name","uploadUrl","expectedMimeType"],"properties":{"name":{"type":"string"},"uploadUrl":{"type":"string","description":"Short-lived scoped signed PUT URL."},"expectedMimeType":{"type":"string"}},"additionalProperties":false}}},"additionalProperties":false},"parameters":{"type":"object","description":"Step-specific scientific algorithm arguments.","additionalProperties":true},"manifestFragment":{"type":"object","description":"Provenance slice to be populated and recorded by the worker.","required":["containerDigest","randomSeeds"],"properties":{"containerDigest":{"type":"string"},"randomSeeds":{"type":"object","additionalProperties":{"type":"integer"}},"softwareVersions":{"type":"object","additionalProperties":{"type":"string"}}},"additionalProperties":true}},"additionalProperties":false},{"$schema":"https://json-schema.org/draft/2020-12/schema","$id":"https://contracts.cellweave.dev/schemas/jobs/workflow-execution.v1.json","title":"WorkflowExecutionContracts","description":"INTERNAL trusted Phase 4 execution boundaries; no keys, JWTs, or customer authority.","type":"object","additionalProperties":false,"$defs":{"ExecutionCeilings":{"type":"object","properties":{"resourceClass":{"$ref":"https://contracts.cellweave.dev/schemas/domain/resource-class.v1.json"},"estimatedComputeUnits":{"type":"number","exclusiveMinimum":0},"maxComputeUnits":{"type":"integer","minimum":1,"maximum":9007199254740991,"description":"Phase 4 CPU execution safety budget in process CPU seconds, not credits or pricing."},"maxRuntimeSeconds":{"type":"integer","minimum":1,"maximum":2147483647},"maxMemoryClass":{"$ref":"https://contracts.cellweave.dev/schemas/domain/resource-class.v1.json"},"maxInputBytes":{"type":"integer","minimum":1,"maximum":9007199254740991},"maxDecompressedBytes":{"type":"integer","minimum":1,"maximum":9007199254740991},"maxCompressionRatio":{"type":"number","exclusiveMinimum":0}},"required":["resourceClass","estimatedComputeUnits","maxComputeUnits","maxRuntimeSeconds","maxMemoryClass","maxInputBytes","maxDecompressedBytes","maxCompressionRatio"],"additionalProperties":false},"ExecutionEnvelope":{"type":"object","properties":{"schemaVersion":{"const":"1.0.0","type":"string"},"analysisRunId":{"type":"string","minLength":1},"organizationId":{"type":"string","minLength":1},"projectId":{"type":"string","minLength":1},"datasetVersionId":{"type":"string","minLength":1},"importId":{"type":"string","minLength":1},"pipelineVersion":{"type":"string","minLength":1},"stepId":{"type":"string","minLength":1},"submissionId":{"type":"string","minLength":1},"ceilings":{"$ref":"#/$defs/ExecutionCeilings"},"organism":{"$ref":"https://contracts.cellweave.dev/schemas/domain/organism.v1.json"},"geneIdScheme":{"$ref":"https://contracts.cellweave.dev/schemas/domain/gene-id-scheme.v1.json"},"referenceBuild":{"type":["string","null"]},"mapping":{"$ref":"https://contracts.cellweave.dev/schemas/domain/metadata-mapping-submission.v1.json"},"deadlineAt":{"type":"string","format":"date-time"},"environment":{"$ref":"https://contracts.cellweave.dev/schemas/domain/service-environment.v1.json"}},"required":["schemaVersion","analysisRunId","organizationId","projectId","datasetVersionId","importId","pipelineVersion","stepId","submissionId","ceilings","organism","geneIdScheme","referenceBuild","deadlineAt","environment"],"additionalProperties":false},"ExecutionSourceCapability":{"type":"object","properties":{"datasetFileId":{"type":"string","minLength":1},"fileName":{"type":"string","minLength":1},"byteSize":{"type":"integer","minimum":0,"maximum":9007199254740991},"sha256":{"type":"string","pattern":"^[a-f0-9]{64}$"},"role":{"$ref":"https://contracts.cellweave.dev/schemas/domain/import-file-role.v1.json"},"ordinal":{"type":"integer","minimum":0,"maximum":2147483647},"downloadUrl":{"type":"string","format":"uri"}},"required":["datasetFileId","fileName","byteSize","sha256","role","ordinal","downloadUrl"],"additionalProperties":false},"PreparedExecution":{"type":"object","properties":{"envelope":{"$ref":"#/$defs/ExecutionEnvelope"},"sourceFormat":{"$ref":"https://contracts.cellweave.dev/schemas/domain/source-format.v1.json"},"sourceChecksum":{"type":"string","pattern":"^[a-f0-9]{64}$"},"files":{"type":"array","minItems":1,"items":{"$ref":"#/$defs/ExecutionSourceCapability"}},"publication":{"$ref":"https://contracts.cellweave.dev/schemas/jobs/canonical-artifact-publication-capabilities.v1.json"}},"required":["envelope","sourceFormat","sourceChecksum","files","publication"],"additionalProperties":false},"ExecutionResult":{"type":"object","properties":{"analysisRunId":{"type":"string","minLength":1},"submissionId":{"type":"string","minLength":1},"publication":{"$ref":"https://contracts.cellweave.dev/schemas/jobs/canonical-artifact-publication-result.v1.json"},"canonicalization":{"$ref":"https://contracts.cellweave.dev/schemas/jobs/canonicalization-result.v1.json"},"usage":{"$ref":"#/$defs/ExecutionUsage"}},"required":["analysisRunId","submissionId","publication","canonicalization"],"additionalProperties":false},"ExecutionProjection":{"type":"object","properties":{"analysisRunId":{"type":"string","minLength":1},"sequence":{"type":"integer","minimum":1,"maximum":2147483647},"status":{"$ref":"https://contracts.cellweave.dev/schemas/domain/run-state.v1.json"},"stepState":{"$ref":"https://contracts.cellweave.dev/schemas/domain/workflow-step-state.v1.json"},"failureCode":{"type":"string","minLength":1,"pattern":"^[A-Z0-9_]{1,100}$"}},"required":["analysisRunId","sequence","status","stepState"],"additionalProperties":false},"ExecutionControl":{"type":"object","properties":{"analysisRunId":{"type":"string","minLength":1},"status":{"$ref":"https://contracts.cellweave.dev/schemas/domain/run-state.v1.json"},"cancelRequested":{"type":"boolean"},"projectionVersion":{"type":"integer","minimum":0},"providerJobId":{"type":["string","null"]},"providerState":{"type":"string","enum":["UNKNOWN","PENDING","RUNNING","COMPLETED","FAILED","CANCELLED","TIMEOUT"]},"finalizationStarted":{"type":"boolean"},"result":{"anyOf":[{"$ref":"#/$defs/ExecutionResult"},{"type":"null"}]},"submissionId":{"type":"string","minLength":1}},"required":["analysisRunId","status","cancelRequested","projectionVersion","providerJobId","providerState","finalizationStarted","result","submissionId"],"additionalProperties":false},"ComputeCancellationResponse":{"type":"object","properties":{"jobId":{"type":"string","minLength":1},"providerJobId":{"type":"string","minLength":1},"status":{"type":"string","enum":["UNKNOWN","PENDING","RUNNING","COMPLETED","FAILED","CANCELLED","TIMEOUT"]},"startedAt":{"type":"string","format":"date-time"},"completedAt":{"type":"string","format":"date-time"},"exitCode":{"type":"integer"},"errorMessage":{"type":"string"}},"required":["jobId","status","startedAt"],"additionalProperties":false},"ExecutionUsage":{"type":"object","required":["cpuSeconds","memoryMegabyteSeconds"],"properties":{"cpuSeconds":{"type":"number","minimum":0},"gpuSeconds":{"type":"number","minimum":0,"default":0},"memoryMegabyteSeconds":{"type":"number","minimum":0},"peakMemoryBytes":{"type":"integer","minimum":0}},"additionalProperties":false}}},{"$schema":"https://json-schema.org/draft/2020-12/schema","$id":"https://contracts.cellweave.dev/schemas/manifests/artifact-manifest.v1.json","title":"ArtifactManifest","description":"Artifact Manifest recording immutable scientific artifacts, storage references, checksums, and lineage.","type":"object","required":["schemaVersion","artifactId","runId","type","storage","sha256","sizeBytes","mimeType","producingStepId","lineage","createdAt"],"properties":{"schemaVersion":{"type":"string","description":"Semantic version of the Artifact Manifest schema.","pattern":"^1\\.[0-9]+\\.[0-9]+$"},"artifactId":{"type":"string","description":"Unique identifier of the artifact (e.g. UUIDv7)."},"runId":{"type":"string","description":"ID of the analysis run producing this artifact."},"type":{"type":"string","description":"Domain artifact type classification.","enum":["SOURCE_DATASET","CANONICAL_DATASET","QC_REPORT","NORMALIZED_DATASET","EMBEDDING","CLUSTERS","ANNOTATIONS","MARKER_TABLE","DE_TABLE","PATHWAY_TABLE","FIGURE","REPORT","RUN_MANIFEST","EXPORT_BUNDLE","FILTERED_DATASET"]},"storage":{"type":"object","required":["provider","bucket","objectKey"],"properties":{"provider":{"type":"string","enum":["R2","S3_COMPATIBLE"],"description":"Underlying storage provider abstraction."},"bucket":{"type":"string","description":"Private bucket identifier."},"objectKey":{"type":"string","description":"Object storage key following org/project/runs hierarchy."}},"additionalProperties":false},"sha256":{"type":"string","description":"Cryptographic SHA-256 hash of artifact payload bytes.","pattern":"^[a-f0-9]{64}$"},"sizeBytes":{"type":"integer","description":"Exact byte size of the stored object.","minimum":0},"mimeType":{"type":"string","description":"MIME type (e.g. application/x-hdf5, application/json, text/csv, image/png)."},"producingStepId":{"type":"string","description":"Identifier of the workflow step that generated this artifact."},"lineage":{"type":"array","description":"Directed lineage connections linking this artifact to its source/parent artifacts.","items":{"type":"object","required":["parentArtifactId","relationship"],"properties":{"parentArtifactId":{"type":"string","description":"Identifier of the parent artifact."},"relationship":{"type":"string","description":"Relationship type in the provenance DAG connecting this artifact to its parent."}},"additionalProperties":false}},"metadata":{"type":"object","description":"Optional step-specific structured output descriptors (e.g. embedding dimensions, cluster count).","additionalProperties":true},"createdAt":{"type":"string","format":"date-time","description":"ISO 8601 creation timestamp."}},"additionalProperties":false},{"$schema":"https://json-schema.org/draft/2020-12/schema","$id":"https://contracts.cellweave.dev/schemas/manifests/dataset-import-manifest.v1.json","title":"DatasetImportManifest","description":"Internal trusted representation of an immutable dataset import manifest and participating member files.","type":"object","required":["id","organizationId","datasetVersionId","sourceFormat","sourceChecksum","files","createdAt"],"properties":{"id":{"type":"string","description":"Unique identifier of the import manifest (imp_...)."},"organizationId":{"type":"string","description":"Tenant organization identifier."},"datasetVersionId":{"type":"string","description":"Canonical dataset version ID (dsv_...)."},"sourceFormat":{"$ref":"https://contracts.cellweave.dev/schemas/domain/source-format.v1.json","description":"Authoritative input format."},"sourceChecksum":{"type":"string","pattern":"^[a-f0-9]{64}$","description":"Authoritative aggregate source SHA-256."},"files":{"type":"array","minItems":1,"items":{"type":"object","required":["datasetFileId","fileName","role","ordinal","byteSize","sha256"],"properties":{"datasetFileId":{"type":"string","description":"Physical dataset file ID (dsf_...)."},"fileName":{"type":"string","description":"Persisted file name."},"role":{"$ref":"https://contracts.cellweave.dev/schemas/domain/import-file-role.v1.json","description":"Assigned role."},"ordinal":{"type":"integer","minimum":0,"description":"Role ordinal."},"byteSize":{"type":"integer","minimum":0,"description":"File size in bytes."},"sha256":{"type":"string","pattern":"^[a-f0-9]{64}$","description":"Verified file SHA-256."}},"additionalProperties":false}},"createdAt":{"type":"string","format":"date-time","description":"Timestamp when the manifest was registered."}},"additionalProperties":false},{"$schema":"https://json-schema.org/draft/2020-12/schema","$id":"https://contracts.cellweave.dev/schemas/manifests/import-file-selection.v1.json","title":"SelectedImportFile","description":"Selected file participation binding for import manifest registration.","type":"object","required":["datasetFileId","role","ordinal"],"properties":{"datasetFileId":{"type":"string","description":"Canonical dataset file ID (dsf_...)."},"role":{"$ref":"https://contracts.cellweave.dev/schemas/domain/import-file-role.v1.json","description":"Functional scientific role assigned to this file."},"ordinal":{"type":"integer","minimum":0,"description":"Zero-based order index for files sharing the same role."}},"additionalProperties":false},{"$schema":"https://json-schema.org/draft/2020-12/schema","$id":"https://contracts.cellweave.dev/schemas/manifests/register-manifest-request.v1.json","title":"RegisterManifestRequest","description":"Public web API request to register an immutable import manifest from confirmed file selections.","type":"object","required":["datasetVersionId","files"],"properties":{"datasetVersionId":{"type":"string","description":"Canonical dataset version ID (dsv_...)."},"files":{"type":"array","description":"List of participating file role assignments.","minItems":1,"items":{"$ref":"https://contracts.cellweave.dev/schemas/manifests/import-file-selection.v1.json"}}},"additionalProperties":false},{"$schema":"https://json-schema.org/draft/2020-12/schema","$id":"https://contracts.cellweave.dev/schemas/manifests/register-manifest-response.v1.json","title":"RegisterManifestResponse","description":"Public web API response returned after successful immutable manifest registration.","type":"object","required":["importId","datasetVersionId","sourceFormat","sourceChecksum","fileCount"],"properties":{"importId":{"type":"string","description":"Unique identifier of the registered import manifest (imp_...)."},"datasetVersionId":{"type":"string","description":"Canonical dataset version ID (dsv_...)."},"sourceFormat":{"$ref":"https://contracts.cellweave.dev/schemas/domain/source-format.v1.json","description":"Validated source format."},"sourceChecksum":{"type":"string","pattern":"^[a-f0-9]{64}$","description":"Authoritative aggregate source SHA-256 checksum."},"fileCount":{"type":"integer","minimum":1,"description":"Total count of participating files registered."}},"additionalProperties":false},{"$schema":"https://json-schema.org/draft/2020-12/schema","$id":"https://contracts.cellweave.dev/schemas/manifests/run-manifest.v1.json","title":"RunManifest","description":"Immutable Run Manifest recording end-to-end scientific lineage and execution provenance.","type":"object","required":["schemaVersion","runId","pipeline","container","input","organism","parameters","references","software","randomSeeds","steps","artifacts","timestamps"],"properties":{"schemaVersion":{"type":"string","description":"Semantic version of the Run Manifest schema.","pattern":"^1\\.[0-9]+\\.[0-9]+$"},"runId":{"type":"string","description":"Unique identifier of the analysis run."},"pipeline":{"type":"object","required":["name","version"],"properties":{"name":{"type":"string","description":"Canonical pipeline name (e.g. cellweave-standard-scrna)."},"version":{"type":"string","description":"Immutable pipeline version pinned for this run."}},"additionalProperties":false},"container":{"type":"object","required":["digest"],"properties":{"digest":{"type":"string","description":"Immutable sha256 container digest used for compute execution.","pattern":"^sha256:[a-f0-9]{64}$"},"image":{"type":"string","description":"Container image repository URI."}},"additionalProperties":false},"input":{"type":"object","required":["datasetVersionId","sha256"],"properties":{"datasetVersionId":{"type":"string","description":"Immutable dataset version ID used as primary canonical input."},"sha256":{"type":"string","description":"SHA-256 digest of the canonical input dataset.","pattern":"^[a-f0-9]{64}$"},"sourceFormat":{"type":"string","description":"Source format from which canonical data was imported (e.g. h5ad, 10x, csv_matrix)."}},"additionalProperties":false},"organism":{"type":"string","enum":["human","mouse"],"description":"Organism/species of the processed single-cell dataset."},"parameters":{"type":"object","description":"Complete map of user and pipeline execution parameters.","additionalProperties":true},"references":{"type":"object","description":"Reference genomes, annotation models, and pathway database versions.","properties":{"genomeBuild":{"type":"string","description":"Reference genome build when available (e.g. GRCh38, GRCm39)."},"annotationModel":{"type":"object","properties":{"name":{"type":"string"},"version":{"type":"string"},"referenceDataset":{"type":"string"}},"additionalProperties":true},"pathwayDatabase":{"type":"object","properties":{"name":{"type":"string"},"version":{"type":"string"}},"additionalProperties":true}},"additionalProperties":true},"software":{"type":"object","description":"Pinned software and library dependencies (e.g. Scanpy, Anndata, Scrublet).","additionalProperties":{"type":"string"}},"randomSeeds":{"type":"object","description":"Stochastic algorithm random seeds for reproducibility (e.g. UMAP, PCA, Leiden).","additionalProperties":{"type":"integer"}},"steps":{"type":"array","description":"Execution records for each logical workflow step.","items":{"type":"object","required":["stepId","name","status","startedAt","completedAt"],"properties":{"stepId":{"type":"string"},"name":{"type":"string"},"version":{"type":"string"},"status":{"$ref":"https://contracts.cellweave.dev/schemas/domain/workflow-step-state.v1.json"},"startedAt":{"type":"string","format":"date-time"},"completedAt":{"type":"string","format":"date-time"},"computeUnits":{"type":"number"},"resourceClass":{"$ref":"https://contracts.cellweave.dev/schemas/domain/resource-class.v1.json"},"outputArtifactIds":{"type":"array","items":{"type":"string"}}},"additionalProperties":false}},"artifacts":{"type":"array","description":"Summary metadata of all artifacts generated by the run.","items":{"type":"object","required":["artifactId","type","sha256","objectKey"],"properties":{"artifactId":{"type":"string"},"type":{"type":"string"},"sha256":{"type":"string","pattern":"^[a-f0-9]{64}$"},"objectKey":{"type":"string"},"sizeBytes":{"type":"integer"}},"additionalProperties":false}},"warnings":{"type":"array","description":"Durable scientific warnings issued during run execution (e.g. low cell count, weak replicate power).","items":{"type":"object","required":["code","message","step"],"properties":{"code":{"type":"string"},"message":{"type":"string"},"step":{"type":"string"},"details":{"type":"object","additionalProperties":true}},"additionalProperties":false},"default":[]},"timestamps":{"type":"object","required":["startedAt","completedAt"],"properties":{"startedAt":{"type":"string","format":"date-time"},"completedAt":{"type":"string","format":"date-time"}},"additionalProperties":false}},"additionalProperties":false},{"$schema":"https://json-schema.org/draft/2020-12/schema","$id":"https://contracts.cellweave.dev/schemas/tenancy/organization-role.v1.json","title":"OrganizationRole","description":"Canonical CellWeave organization role defining baseline platform capabilities.","type":"string","enum":["owner","admin","bioinformatician","scientist","viewer"]},{"$schema":"https://json-schema.org/draft/2020-12/schema","$id":"https://contracts.cellweave.dev/schemas/tenancy/tenant-context.v1.json","title":"TenantContext","description":"Server-validated multi-tenant execution context for authenticated requests and workflows.","type":"object","required":["organizationId","userId","role"],"properties":{"organizationId":{"type":"string","description":"Tenant organization identifier (UUIDv7)."},"userId":{"type":"string","description":"Authenticated user identifier."},"role":{"$ref":"https://contracts.cellweave.dev/schemas/tenancy/organization-role.v1.json","description":"Validated organization role of the user within this organization."}},"additionalProperties":false}] as const;
