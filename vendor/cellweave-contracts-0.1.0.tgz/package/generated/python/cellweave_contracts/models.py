"""
CellWeave Cross-Language Contracts — Generated Pydantic v2 Models.

AUTOMATICALLY GENERATED FROM CANONICAL JSON SCHEMAS & OPENAPI 3.1.
DO NOT EDIT MANUALLY.

Single source of truth: /schemas/ and /openapi/
"""

from __future__ import annotations

from datetime import datetime
from enum import Enum
import re
from typing import Annotated, Any, Dict, List, Literal, Optional
from urllib.parse import urlparse
from pydantic import BaseModel, ConfigDict, Field, field_validator


# --- Domain State Enums (derived from canonical JSON schemas) ---

class RunState(str, Enum):
    DRAFT = "DRAFT"
    UPLOADING = "UPLOADING"
    START_PENDING = "START_PENDING"
    VALIDATING = "VALIDATING"
    QC_RUNNING = "QC_RUNNING"
    QC_REVIEW_REQUIRED = "QC_REVIEW_REQUIRED"
    QUEUED = "QUEUED"
    RUNNING = "RUNNING"
    PAUSED_QUOTA = "PAUSED_QUOTA"
    CANCEL_REQUESTED = "CANCEL_REQUESTED"
    CANCELLED = "CANCELLED"
    SUCCEEDED = "SUCCEEDED"
    FAILED = "FAILED"

class WorkflowStepState(str, Enum):
    PENDING = "PENDING"
    QUEUED = "QUEUED"
    RUNNING = "RUNNING"
    SUCCEEDED = "SUCCEEDED"
    RETRYING = "RETRYING"
    FAILED = "FAILED"
    SKIPPED = "SKIPPED"
    CANCELLED = "CANCELLED"

class UploadState(str, Enum):
    CREATED = "CREATED"
    UPLOADING = "UPLOADING"
    UPLOADED = "UPLOADED"
    VERIFYING = "VERIFYING"
    VERIFIED = "VERIFIED"
    IMPORTED = "IMPORTED"
    FAILED = "FAILED"
    ABORTED = "ABORTED"
    EXPIRED = "EXPIRED"
    QUARANTINED = "QUARANTINED"

class AccountState(str, Enum):
    ACTIVE = "ACTIVE"
    PAST_DUE = "PAST_DUE"
    SUSPENDED = "SUSPENDED"
    CLOSING = "CLOSING"
    DELETED = "DELETED"

class ResourceClass(str, Enum):
    CPU_SMALL = "CPU_SMALL"
    CPU_MEMORY = "CPU_MEMORY"
    CPU_HIGH_MEMORY = "CPU_HIGH_MEMORY"
    GPU_SMALL = "GPU_SMALL"
    GPU_LARGE = "GPU_LARGE"

class ArtifactType(str, Enum):
    SOURCE_DATASET = "SOURCE_DATASET"
    CANONICAL_DATASET = "CANONICAL_DATASET"
    QC_REPORT = "QC_REPORT"
    NORMALIZED_DATASET = "NORMALIZED_DATASET"
    EMBEDDING = "EMBEDDING"
    CLUSTERS = "CLUSTERS"
    ANNOTATIONS = "ANNOTATIONS"
    MARKER_TABLE = "MARKER_TABLE"
    DE_TABLE = "DE_TABLE"
    PATHWAY_TABLE = "PATHWAY_TABLE"
    FIGURE = "FIGURE"
    REPORT = "REPORT"
    RUN_MANIFEST = "RUN_MANIFEST"
    EXPORT_BUNDLE = "EXPORT_BUNDLE"
    FILTERED_DATASET = "FILTERED_DATASET"

class ScientificJobType(str, Enum):
    validate_dataset = "validate_dataset"
    run_qc = "run_qc"
    filter_cells = "filter_cells"
    normalize = "normalize"
    select_hvg = "select_hvg"
    run_pca = "run_pca"
    build_neighbors = "build_neighbors"
    run_umap = "run_umap"
    cluster = "cluster"
    annotate = "annotate"
    find_markers = "find_markers"
    run_differential_expression = "run_differential_expression"
    run_pathway_analysis = "run_pathway_analysis"
    generate_exports = "generate_exports"

class OrganizationRole(str, Enum):
    owner = "owner"
    admin = "admin"
    bioinformatician = "bioinformatician"
    scientist = "scientist"
    viewer = "viewer"

class SourceFormat(str, Enum):
    H5AD = "H5AD"
    TENX_H5 = "TENX_H5"
    TENX_MTX = "TENX_MTX"
    GENERIC_MATRIX = "GENERIC_MATRIX"

class ImportFileRole(str, Enum):
    PRIMARY = "PRIMARY"
    MATRIX = "MATRIX"
    FEATURES = "FEATURES"
    BARCODES = "BARCODES"
    CELL_METADATA = "CELL_METADATA"
    FEATURE_METADATA = "FEATURE_METADATA"

class Organism(str, Enum):
    HUMAN = "HUMAN"
    MOUSE = "MOUSE"

class GeneIdScheme(str, Enum):
    ENSEMBL = "ENSEMBL"
    SYMBOL = "SYMBOL"

class MatrixOrientation(str, Enum):
    CELLS_BY_GENES = "CELLS_BY_GENES"
    GENES_BY_CELLS = "GENES_BY_CELLS"

class InspectionStatus(str, Enum):
    VALID = "VALID"
    NEEDS_MAPPING = "NEEDS_MAPPING"
    INVALID = "INVALID"

class ScientificIssueCode(str, Enum):
    UNSUPPORTED_FORMAT = "UNSUPPORTED_FORMAT"
    FORMAT_MISMATCH = "FORMAT_MISMATCH"
    MALFORMED_INPUT = "MALFORMED_INPUT"
    MISSING_COMPONENT = "MISSING_COMPONENT"
    INVALID_IMPORT_CARDINALITY = "INVALID_IMPORT_CARDINALITY"
    DIMENSION_MISMATCH = "DIMENSION_MISMATCH"
    DUPLICATE_CELL_IDS = "DUPLICATE_CELL_IDS"
    AMBIGUOUS_GENE_IDENTIFIERS = "AMBIGUOUS_GENE_IDENTIFIERS"
    AMBIGUOUS_ORIENTATION = "AMBIGUOUS_ORIENTATION"
    MISSING_REQUIRED_METADATA = "MISSING_REQUIRED_METADATA"
    UNRESOLVED_SPECIES = "UNRESOLVED_SPECIES"
    UNSUPPORTED_SPECIES = "UNSUPPORTED_SPECIES"
    UNSUPPORTED_MODALITY = "UNSUPPORTED_MODALITY"
    NON_COUNT_INPUT = "NON_COUNT_INPUT"
    AMBIGUOUS_COUNT_SEMANTICS = "AMBIGUOUS_COUNT_SEMANTICS"
    RESOURCE_LIMIT = "RESOURCE_LIMIT"
    SECURITY_REJECTED = "SECURITY_REJECTED"
    CANONICALIZATION_FAILED = "CANONICALIZATION_FAILED"

class ScientificIssueSeverity(str, Enum):
    ERROR = "ERROR"
    WARNING = "WARNING"
    REQUIRES_USER_INPUT = "REQUIRES_USER_INPUT"

class CanonicalArtifactPublicationStatus(str, Enum):
    PUBLISHED = "PUBLISHED"
    ALREADY_PRESENT = "ALREADY_PRESENT"


# --- Tenancy & Identity Models ---

class TenantContext(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    organizationId: str
    userId: str
    role: OrganizationRole


# --- Domain Error Model ---

class DomainError(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    code: str = Field(..., description="Machine-readable error code")
    message: str = Field(..., description="User-facing safe description")
    technicalDetail: str = Field(..., description="Diagnostic context excluding PHI and raw data")
    recommendedAction: str = Field(..., description="Resolution guidance")
    correlationId: str = Field(..., description="Unique request or run trace correlation ID")
    retryable: bool = Field(False, description="Whether retry is permitted without change")
    details: Optional[Dict[str, Any]] = Field(None, description="Structured error details")


# --- Compute Provider Models ---

class ComputeJobSubmitRequest(BaseModel):
    execution: Optional[PreparedExecution] = None
    model_config = ConfigDict(frozen=True, extra="forbid")

    jobId: str
    jobType: str
    resourceClass: ResourceClass
    payloadUri: str
    maxRuntimeSeconds: int = Field(..., ge=1)
    correlationId: str
    tags: Optional[Dict[str, str]] = None


class ComputeJobStatusResponse(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    jobId: str
    providerJobId: str
    status: Literal["PENDING", "RUNNING", "COMPLETED", "FAILED", "CANCELLED", "TIMEOUT", "UNKNOWN"]
    startedAt: str
    completedAt: Optional[str] = None
    exitCode: Optional[int] = None
    errorMessage: Optional[str] = None


class ComputeJobCancelRequest(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    jobId: str
    providerJobId: Optional[str] = None
    reason: str


class ComputeJobMetrics(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    cpuSeconds: float = Field(..., ge=0)
    gpuSeconds: float = Field(0.0, ge=0)
    memoryMegabyteSeconds: float = Field(..., ge=0)
    peakMemoryBytes: Optional[int] = Field(None, ge=0)


class ComputeJobResultResponse(BaseModel):
    executionResult: Optional[ExecutionResult] = None
    model_config = ConfigDict(frozen=True, extra="forbid")

    jobId: str
    providerJobId: str
    status: Literal["COMPLETED", "FAILED", "CANCELLED"]
    metrics: ComputeJobMetrics
    resultUri: Optional[str] = None
    error: Optional[DomainError] = None


# --- Scientific Job Payload Models ---

class ScopedPrimaryDatasetInput(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    downloadUrl: str
    sha256: str = Field(..., pattern=r"^[a-f0-9]{64}$")
    format: Optional[str] = None


class ScopedAuxiliaryInput(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    name: str
    downloadUrl: str
    sha256: str = Field(..., pattern=r"^[a-f0-9]{64}$")


class ScopedOutputTarget(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    name: str
    uploadUrl: str
    expectedMimeType: str


class ScientificJobInputs(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    primaryDataset: ScopedPrimaryDatasetInput
    auxiliaryInputs: Optional[List[ScopedAuxiliaryInput]] = None


class ScientificJobOutputs(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    targets: List[ScopedOutputTarget]


class ScientificJobManifestFragment(BaseModel):
    model_config = ConfigDict(frozen=True, extra="allow")

    containerDigest: str
    randomSeeds: Dict[str, int]
    softwareVersions: Optional[Dict[str, str]] = None


class ScientificJobPayload(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    schemaVersion: str = Field(..., pattern=r"^1.[0-9]+.[0-9]+$")
    pipelineVersion: str
    jobId: str
    runId: str
    stepId: str
    jobType: ScientificJobType
    inputs: ScientificJobInputs
    outputs: ScientificJobOutputs
    parameters: Dict[str, Any]
    manifestFragment: ScientificJobManifestFragment
    resourceClass: Optional[ResourceClass] = None


# --- Manifest Models ---

class PipelineRef(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    name: str
    version: str


class ContainerRef(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    digest: str = Field(..., pattern=r"^sha256:[a-f0-9]{64}$")
    image: Optional[str] = None


class InputDatasetRef(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    datasetVersionId: str
    sha256: str = Field(..., pattern=r"^[a-f0-9]{64}$")
    sourceFormat: Optional[str] = None


class RunManifestStep(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    stepId: str
    name: str
    status: WorkflowStepState
    startedAt: str
    completedAt: str
    version: Optional[str] = None
    computeUnits: Optional[float] = None
    resourceClass: Optional[ResourceClass] = None
    outputArtifactIds: Optional[List[str]] = None


class RunManifestArtifactSummary(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    artifactId: str
    type: str
    sha256: str = Field(..., pattern=r"^[a-f0-9]{64}$")
    objectKey: str
    sizeBytes: Optional[int] = None


class ScientificWarning(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    code: str
    message: str
    step: str
    details: Optional[Dict[str, Any]] = None


class ManifestTimestamps(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    startedAt: str
    completedAt: str


class RunManifest(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    schemaVersion: str = Field(..., pattern=r"^1.[0-9]+.[0-9]+$")
    runId: str
    pipeline: PipelineRef
    container: ContainerRef
    input: InputDatasetRef
    organism: Literal["human", "mouse"]
    parameters: Dict[str, Any]
    references: Dict[str, Any]
    software: Dict[str, str]
    randomSeeds: Dict[str, int]
    steps: List[RunManifestStep]
    artifacts: List[RunManifestArtifactSummary]
    timestamps: ManifestTimestamps
    warnings: List[ScientificWarning] = Field(default_factory=list)


class ArtifactLineageRelation(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    parentArtifactId: str
    relationship: str


class ArtifactStorageRef(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    provider: Literal["R2", "S3_COMPATIBLE"]
    bucket: str
    objectKey: str


class ArtifactManifest(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    schemaVersion: str = Field(..., pattern=r"^1.[0-9]+.[0-9]+$")
    artifactId: str
    runId: str
    type: ArtifactType
    storage: ArtifactStorageRef
    sha256: str = Field(..., pattern=r"^[a-f0-9]{64}$")
    sizeBytes: int = Field(..., ge=0)
    mimeType: str
    producingStepId: str
    lineage: List[ArtifactLineageRelation]
    createdAt: str
    metadata: Optional[Dict[str, Any]] = None


# --- Event Models ---

class UsageMeasurements(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    cpuSeconds: float = Field(..., ge=0)
    gpuSeconds: float = Field(0.0, ge=0)
    memoryClass: Optional[ResourceClass] = None
    bytesProcessed: Optional[int] = Field(None, ge=0)
    storageByteHours: Optional[float] = Field(None, ge=0)
    egressBytes: Optional[int] = Field(None, ge=0)


class UsageEvent(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    schemaVersion: str = Field(..., pattern=r"^1.[0-9]+.[0-9]+$")
    idempotencyKey: str = Field(..., pattern=r"^.+:.+:[0-9]+$")
    organizationId: str
    projectId: str
    runId: str
    stepId: str
    attempt: int = Field(..., ge=1)
    measurements: UsageMeasurements
    timestamp: str


class AuditActor(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    actorId: str
    actorType: str
    ipHash: Optional[str] = None
    userAgent: Optional[str] = None


class AuditEvent(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    schemaVersion: str = Field(..., pattern=r"^1.[0-9]+.[0-9]+$")
    eventId: str
    organizationId: str
    actor: AuditActor
    action: str
    resourceType: str
    resourceId: str
    timestamp: str
    metadata: Optional[Dict[str, Any]] = None


class ServiceEvent(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    schemaVersion: str = Field(..., pattern=r"^1.[0-9]+.[0-9]+$")
    eventId: str
    eventType: str
    source: str
    correlationId: str
    data: Dict[str, Any]
    timestamp: str
    organizationId: Optional[str] = None


class PolarWebhookReceipt(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    schemaVersion: str = Field(..., pattern=r"^1.[0-9]+.[0-9]+$")
    receiptId: str
    externalEventId: str
    eventType: str
    receivedAt: str
    payload: Dict[str, Any]
    signatureVerified: bool = True


# --- OpenAPI Phase 0 API Models ---

class HealthResponse(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    status: Literal["healthy", "degraded", "unhealthy"]
    version: str
    schemaVersion: str
    timestamp: str


# --- Phase 3 Scientific Import Models ---

class ScientificIssue(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    code: ScientificIssueCode
    severity: ScientificIssueSeverity
    message: str
    userActionRequired: bool
    field: Optional[str] = None


class SelectedImportFile(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    datasetFileId: str
    role: ImportFileRole
    ordinal: int = Field(0, ge=0)


class RegisterManifestRequest(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    datasetVersionId: str
    files: List[SelectedImportFile] = Field(..., min_length=1)


class RegisterManifestResponse(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    importId: str
    datasetVersionId: str
    sourceFormat: SourceFormat
    sourceChecksum: str = Field(..., pattern=r"^[a-f0-9]{64}$")
    fileCount: int = Field(..., ge=1)


class ManifestFileItem(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    datasetFileId: str
    fileName: str
    role: ImportFileRole
    ordinal: int = Field(..., ge=0)
    byteSize: int = Field(..., ge=0)
    sha256: str = Field(..., pattern=r"^[a-f0-9]{64}$")


class DatasetImportManifest(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    id: str
    organizationId: str
    datasetVersionId: str
    sourceFormat: SourceFormat
    sourceChecksum: str = Field(..., pattern=r"^[a-f0-9]{64}$")
    files: List[ManifestFileItem] = Field(..., min_length=1)
    createdAt: str


class ImportInspectionResult(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    datasetVersionId: str
    sourceFormat: SourceFormat
    status: InspectionStatus
    requiresMapping: bool
    availableCellMetadataColumns: List[str]
    availableFeatureMetadataColumns: List[str]
    issues: List[ScientificIssue]
    cellCountEstimate: Optional[int] = Field(None, ge=0)
    geneCountEstimate: Optional[int] = Field(None, ge=0)
    detectedOrganism: Optional[Organism] = None
    detectedGeneIdScheme: Optional[GeneIdScheme] = None
    referenceBuildCandidate: Optional[str] = None


class SampleMappingEntry(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    sourceValue: str
    sampleKey: str


class MetadataMappingSubmission(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    datasetVersionId: str
    organism: Organism
    geneIdScheme: GeneIdScheme
    referenceBuild: Optional[str] = None
    orientation: Optional[MatrixOrientation] = None
    cellIdColumn: Optional[str] = None
    geneIdColumn: Optional[str] = None
    geneSymbolColumn: Optional[str] = None
    matrixCellIdColumn: Optional[str] = None
    matrixFeatureIdColumn: Optional[str] = None
    cellMetadataJoinColumn: Optional[str] = None
    featureMetadataJoinColumn: Optional[str] = None
    cellAxisIndexColumn: Optional[str] = None
    featureAxisIndexColumn: Optional[str] = None
    sampleColumn: Optional[str] = None
    conditionColumn: Optional[str] = None
    batchColumn: Optional[str] = None
    biologicalReplicateColumn: Optional[str] = None
    technicalReplicateColumn: Optional[str] = None
    sampleMappings: Optional[List[SampleMappingEntry]] = None


class SourceFileTarget(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    datasetFileId: str
    role: ImportFileRole
    localPath: str
    ordinal: int = Field(0, ge=0)


class CanonicalizationRequest(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    datasetVersionId: str
    importId: str
    sourceFormat: SourceFormat
    sourceFiles: List[SourceFileTarget] = Field(..., min_length=1)
    organism: Organism
    geneIdScheme: GeneIdScheme
    referenceBuild: Optional[str] = None
    mapping: Optional[MetadataMappingSubmission] = None


class CanonicalizationResult(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    sourceFormat: SourceFormat
    canonicalFormat: Literal["H5AD"]
    canonicalChecksum: str = Field(..., pattern=r"^[a-f0-9]{64}$")
    organism: Organism
    geneIdScheme: GeneIdScheme
    cellCount: int = Field(..., ge=1)
    geneCount: int = Field(..., ge=1)
    warnings: List[ScientificIssue]
    referenceBuild: Optional[str] = None
    localArtifactPath: Optional[str] = None


_HEADER_NAME_PATTERN = re.compile(r"^[A-Za-z0-9-]+$")
_UTC_ISO_TIMESTAMP_PATTERN = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?Z$")


class CanonicalArtifactPublicationCapabilities(BaseModel):
    """INTERNAL TRUSTED WORKER/CONTROL-PLANE CONTRACT ONLY.

    Never accepted from browser/client input.
    putUrl and getUrl are ephemeral secret capabilities and MUST be redacted from logs and errors.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    datasetVersionId: str = Field(..., min_length=1)
    putUrl: str = Field(..., min_length=1)
    getUrl: str = Field(..., min_length=1)
    expiresAt: str = Field(..., min_length=1)
    requiredPutHeaders: Dict[str, str]
    requiredGetHeaders: Dict[str, str]

    @field_validator("putUrl", "getUrl")
    @classmethod
    def _validate_capability_uri(cls, value: str) -> str:
        parsed = urlparse(value)
        if not parsed.scheme or not parsed.netloc or any(ch.isspace() for ch in value):
            raise ValueError("Capability URL must be a valid absolute URI.")
        return value

    @field_validator("expiresAt")
    @classmethod
    def _validate_utc_expires_at(cls, value: str) -> str:
        if not _UTC_ISO_TIMESTAMP_PATTERN.match(value):
            raise ValueError("expiresAt must be an explicit UTC ISO 8601 timestamp ending in 'Z'.")
        try:
            datetime.fromisoformat(value.replace("Z", "+00:00"))
        except ValueError as exc:
            raise ValueError("expiresAt must be a valid calendar UTC timestamp.") from exc
        return value

    @field_validator("requiredPutHeaders")
    @classmethod
    def _validate_required_put_headers(cls, value: Dict[str, str]) -> Dict[str, str]:
        if value.get("If-None-Match") != "*":
            raise ValueError("requiredPutHeaders must bind 'If-None-Match' to '*' for atomic create-once semantics.")
        for key, header_val in value.items():
            if not _HEADER_NAME_PATTERN.match(key):
                raise ValueError(f"Invalid HTTP header name in requiredPutHeaders: {key!r}")
            if not isinstance(header_val, str) or len(header_val) == 0:
                raise ValueError(f"Header value for {key!r} must be a non-empty string.")
        return value

    @field_validator("requiredGetHeaders")
    @classmethod
    def _validate_required_get_headers(cls, value: Dict[str, str]) -> Dict[str, str]:
        for key, header_val in value.items():
            if not _HEADER_NAME_PATTERN.match(key):
                raise ValueError(f"Invalid HTTP header name in requiredGetHeaders: {key!r}")
            if not isinstance(header_val, str) or len(header_val) == 0:
                raise ValueError(f"Header value for {key!r} must be a non-empty string.")
        return value


class CanonicalArtifactPublicationResult(BaseModel):
    """INTERNAL TRUSTED WORKER/CONTROL-PLANE CONTRACT ONLY.

    Result of publishing and verifying a canonical.h5ad artifact via scoped capabilities.
    Integrity conflicts must fail as errors rather than returning a success status.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    datasetVersionId: str = Field(..., min_length=1)
    canonicalChecksum: str = Field(..., pattern=r"^[a-f0-9]{64}$")
    byteSize: int = Field(..., ge=0)
    status: CanonicalArtifactPublicationStatus



class ServiceScope(str, Enum):
    execution_prepare = "execution.prepare"
    execution_project = "execution.project"
    execution_finalize = "execution.finalize"
    execution_cancel = "execution.cancel"
    capability_issue = "capability.issue"


class ServiceEnvironment(str, Enum):
    local = "local"
    development = "development"
    staging = "staging"
    production = "production"


# Internal Phase 4 execution contracts, generated from canonical schema.
class ExecutionCeilings(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid", allow_inf_nan=False)
    resourceClass: ResourceClass = Field(...)
    estimatedComputeUnits: float = Field(..., gt=0)
    maxComputeUnits: int = Field(..., ge=1, le=9007199254740991)
    maxRuntimeSeconds: int = Field(..., ge=1, le=2147483647)
    maxMemoryClass: ResourceClass = Field(...)
    maxInputBytes: int = Field(..., ge=1, le=9007199254740991)
    maxDecompressedBytes: int = Field(..., ge=1, le=9007199254740991)
    maxCompressionRatio: float = Field(..., gt=0)


class ExecutionEnvelope(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid", allow_inf_nan=False)
    schemaVersion: Literal["1.0.0"] = Field(...)
    analysisRunId: str = Field(..., min_length=1)
    organizationId: str = Field(..., min_length=1)
    projectId: str = Field(..., min_length=1)
    datasetVersionId: str = Field(..., min_length=1)
    importId: str = Field(..., min_length=1)
    pipelineVersion: str = Field(..., min_length=1)
    stepId: str = Field(..., min_length=1)
    submissionId: str = Field(..., min_length=1)
    ceilings: ExecutionCeilings = Field(...)
    organism: Organism = Field(...)
    geneIdScheme: GeneIdScheme = Field(...)
    referenceBuild: str | None = Field(...)
    mapping: MetadataMappingSubmission | None = Field(None)
    deadlineAt: str = Field(...)
    environment: ServiceEnvironment = Field(...)


class ExecutionSourceCapability(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid", allow_inf_nan=False)
    datasetFileId: str = Field(..., min_length=1)
    fileName: str = Field(..., min_length=1)
    byteSize: int = Field(..., ge=0, le=9007199254740991)
    sha256: str = Field(..., pattern="^[a-f0-9]{64}$")
    role: ImportFileRole = Field(...)
    ordinal: int = Field(..., ge=0, le=2147483647)
    downloadUrl: str = Field(...)


class PreparedExecution(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid", allow_inf_nan=False)
    envelope: ExecutionEnvelope = Field(...)
    sourceFormat: SourceFormat = Field(...)
    sourceChecksum: str = Field(..., pattern="^[a-f0-9]{64}$")
    files: list[ExecutionSourceCapability] = Field(..., min_length=1)
    publication: CanonicalArtifactPublicationCapabilities = Field(...)


class ExecutionResult(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid", allow_inf_nan=False)
    analysisRunId: str = Field(..., min_length=1)
    submissionId: str = Field(..., min_length=1)
    publication: CanonicalArtifactPublicationResult = Field(...)
    canonicalization: CanonicalizationResult = Field(...)
    usage: ExecutionUsage | None = Field(None)


class ExecutionProjection(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid", allow_inf_nan=False)
    analysisRunId: str = Field(..., min_length=1)
    sequence: int = Field(..., ge=1, le=2147483647)
    status: RunState = Field(...)
    stepState: WorkflowStepState = Field(...)
    failureCode: str | None = Field(None, pattern="^[A-Z0-9_]{1,100}$", min_length=1)


class ExecutionControl(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid", allow_inf_nan=False)
    analysisRunId: str = Field(..., min_length=1)
    status: RunState = Field(...)
    cancelRequested: bool = Field(...)
    projectionVersion: int = Field(..., ge=0)
    providerJobId: str | None = Field(...)
    providerState: Literal["UNKNOWN", "PENDING", "RUNNING", "COMPLETED", "FAILED", "CANCELLED", "TIMEOUT"] = Field(...)
    finalizationStarted: bool = Field(...)
    result: ExecutionResult | None = Field(...)
    submissionId: str = Field(..., min_length=1)


class ComputeCancellationResponse(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid", allow_inf_nan=False)
    jobId: str = Field(..., min_length=1)
    providerJobId: str | None = Field(None, min_length=1)
    status: Literal["UNKNOWN", "PENDING", "RUNNING", "COMPLETED", "FAILED", "CANCELLED", "TIMEOUT"] = Field(...)
    startedAt: str = Field(...)
    completedAt: str | None = Field(None)
    exitCode: int | None = Field(None)
    errorMessage: str | None = Field(None)


class ExecutionUsage(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid", allow_inf_nan=False)
    cpuSeconds: float = Field(..., ge=0)
    gpuSeconds: float | None = Field(None, ge=0)
    memoryMegabyteSeconds: float = Field(..., ge=0)
    peakMemoryBytes: int | None = Field(None, ge=0)


class QcIssue(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid", allow_inf_nan=False)
    code: Literal["ZERO_COUNT_PERCENTAGE_UNAVAILABLE", "GENE_SYMBOLS_REQUIRED_FOR_QC_GENE_SET", "SAMPLE_ASSIGNMENT_UNAVAILABLE", "CAPTURE_GROUP_UNRESOLVED", "INSUFFICIENT_CELLS", "INSUFFICIENT_FEATURES", "DEGENERATE_DATA", "THRESHOLD_INFERENCE_FAILED", "SCRUBLET_FAILED"] = Field(...)
    groupKey: Annotated[str, Field(max_length=200, min_length=1)] | None = Field(...)
    affectedCells: int = Field(..., ge=0)


class QcSampleBinding(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid", allow_inf_nan=False)
    sampleId: str = Field(..., max_length=200, min_length=1)
    sampleKey: str = Field(..., max_length=200, min_length=1)
    captureGroupKey: Annotated[str, Field(max_length=200, min_length=1)] | None = Field(...)
    expectedDoubletRate: Annotated[float, Field(gt=0, lt=1)] | None = Field(...)


class QcAnalysisParameters(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid", allow_inf_nan=False)
    geneSetPolicy: Literal["cellweave-symbol-prefixes-v1"] = Field(...)
    scrubletProfile: Literal["cellweave-scanpy-scrublet-v1"] = Field(...)
    randomSeed: int = Field(..., ge=0, le=2147483647)
    samples: list[QcSampleBinding] = Field(..., max_length=1000)
    wholeInputSampleId: Annotated[str, Field(max_length=200, min_length=1)] | None = Field(...)


class QcCaptureRequest(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid", allow_inf_nan=False)
    sampleId: str = Field(..., max_length=200, min_length=1)
    captureGroupKey: str = Field(..., max_length=200, min_length=1)


class QcStartRequest(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid", allow_inf_nan=False)
    datasetVersionId: str = Field(..., max_length=200, min_length=1)
    captureBindings: list[QcCaptureRequest] = Field(..., max_length=1000)
    wholeInputSampleId: Annotated[str, Field(max_length=200, min_length=1)] | None = Field(...)


class QcThresholdRule(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid", allow_inf_nan=False)
    metric: Literal["total_counts", "n_genes_by_counts", "total_counts_mt", "pct_counts_mt", "total_counts_ribo", "pct_counts_ribo"] = Field(...)
    minimum: Annotated[float, Field(ge=0)] | None = Field(...)
    maximum: Annotated[float, Field(ge=0)] | None = Field(...)
    sampleKey: Annotated[str, Field(max_length=200, min_length=1)] | None = Field(...)


class QcSelectionParameters(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid", allow_inf_nan=False)
    thresholds: list[QcThresholdRule] = Field(..., max_length=1000)
    doubletHandling: Literal["RETAIN", "EXCLUDE_PREDICTED"] = Field(...)


class QcApprovalRequest(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid", allow_inf_nan=False)
    previewId: str = Field(..., max_length=200, min_length=1)
    reason: str = Field(..., max_length=1000, min_length=1)


class QcHistogramBin(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid", allow_inf_nan=False)
    lower: float = Field(...)
    upper: float = Field(...)
    count: int = Field(..., ge=0)


class QcMetricSummary(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid", allow_inf_nan=False)
    metric: Literal["total_counts", "n_genes_by_counts", "total_counts_mt", "pct_counts_mt", "total_counts_ribo", "pct_counts_ribo"] = Field(...)
    availableCells: int = Field(..., ge=0)
    minimum: float | None = Field(...)
    maximum: float | None = Field(...)
    mean: float | None = Field(...)
    histogram: list[QcHistogramBin] = Field(..., max_length=20)


class QcSampleSummary(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid", allow_inf_nan=False)
    sampleId: str = Field(..., max_length=200, min_length=1)
    sampleKey: str = Field(..., max_length=200, min_length=1)
    cellCount: int = Field(..., ge=0)
    metrics: list[QcMetricSummary] = Field(..., max_length=6)


class QcSoftwareVersion(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid", allow_inf_nan=False)
    name: str = Field(..., max_length=200, min_length=1)
    version: str = Field(..., max_length=200, min_length=1)


class QcParameterValue(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid", allow_inf_nan=False)
    name: str = Field(..., max_length=200, min_length=1)
    value: str = Field(..., max_length=1000)


class QcDoubletAssessment(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid", allow_inf_nan=False)
    captureGroupKey: str = Field(..., max_length=200, min_length=1)
    status: Literal["ASSESSED", "NOT_ASSESSED"] = Field(...)
    reason: Annotated[str, Field(max_length=100)] | None = Field(...)
    cellCount: int = Field(..., ge=0)
    threshold: float | None = Field(...)
    predictedCount: Annotated[int, Field(ge=0)] | None = Field(...)
    parameters: list[QcParameterValue] = Field(..., max_length=40)


class QcSummary(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid", allow_inf_nan=False)
    schemaVersion: Literal["1.0.0"] = Field(...)
    geneSetPolicy: Literal["cellweave-symbol-prefixes-v1"] = Field(...)
    scrubletProfile: Literal["cellweave-scanpy-scrublet-v1"] = Field(...)
    randomSeed: int = Field(..., ge=0)
    cellCount: int = Field(..., ge=1)
    geneCount: int = Field(..., ge=1)
    metrics: list[QcMetricSummary] = Field(..., max_length=6)
    samples: list[QcSampleSummary] = Field(..., max_length=1000)
    sampleQcAvailable: bool = Field(...)
    doublets: list[QcDoubletAssessment] = Field(..., max_length=1000)
    issues: list[QcIssue] = Field(..., max_length=3000)
    software: list[QcSoftwareVersion] = Field(..., max_length=20)
    suggestions: list[QcThresholdRule] = Field(..., max_length=0)


class QcArtifactTarget(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid", allow_inf_nan=False)
    artifactId: str = Field(..., max_length=200, min_length=1)
    type: Literal["QC_REPORT", "FILTERED_DATASET"] = Field(...)
    fileName: Literal["qc_metrics.jsonl.gz", "qc_summary.json", "selection.jsonl.gz", "filtered.h5ad"] = Field(...)
    putUrl: str = Field(...)
    getUrl: str = Field(...)
    expiresAt: str = Field(...)
    ifNoneMatch: Literal["*"] = Field(...)


class QcArtifactInput(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid", allow_inf_nan=False)
    artifactId: str = Field(..., max_length=200, min_length=1)
    type: Literal["CANONICAL_DATASET", "QC_REPORT"] = Field(...)
    sha256: str = Field(..., pattern="^[a-f0-9]{64}$")
    byteSize: int = Field(..., ge=0, le=9007199254740991)
    downloadUrl: str = Field(...)


class QcFilterBinding(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid", allow_inf_nan=False)
    decisionId: str = Field(..., max_length=200, min_length=1)
    canonicalChecksum: str = Field(..., pattern="^[a-f0-9]{64}$")
    selectionArtifactId: str = Field(..., max_length=200, min_length=1)
    selectionChecksum: str = Field(..., pattern="^[a-f0-9]{64}$")
    parametersChecksum: str = Field(..., pattern="^[a-f0-9]{64}$")
    includedCount: int = Field(..., ge=1)
    excludedCount: int = Field(..., ge=0)


class QcPreparedExecution(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid", allow_inf_nan=False)
    schemaVersion: Literal["1.0.0"] = Field(...)
    environment: ServiceEnvironment = Field(...)
    analysisRunId: str = Field(..., max_length=200, min_length=1)
    stepId: str = Field(..., max_length=200, min_length=1)
    submissionId: str = Field(..., max_length=200, min_length=1)
    pipelineVersion: str = Field(..., max_length=200, min_length=1)
    operation: Literal["QC", "PREVIEW", "FILTER"] = Field(...)
    qcRevision: int = Field(..., ge=1)
    deadlineAt: str = Field(...)
    ceilings: ExecutionCeilings = Field(...)
    canonical: QcArtifactInput = Field(...)
    auxiliary: list[QcArtifactInput] = Field(..., max_length=2)
    targets: list[QcArtifactTarget] = Field(..., max_length=2)
    analysis: QcAnalysisParameters = Field(...)
    selection: QcSelectionParameters | None = Field(...)
    decision: QcFilterBinding | None = Field(...)


class QcProducedArtifact(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid", allow_inf_nan=False)
    artifactId: str = Field(..., max_length=200, min_length=1)
    type: Literal["QC_REPORT", "FILTERED_DATASET"] = Field(...)
    fileName: Literal["qc_metrics.jsonl.gz", "qc_summary.json", "selection.jsonl.gz", "filtered.h5ad"] = Field(...)
    sha256: str = Field(..., pattern="^[a-f0-9]{64}$")
    byteSize: int = Field(..., ge=0, le=9007199254740991)
    status: Literal["PUBLISHED", "ALREADY_PRESENT"] = Field(...)


class QcPreviewProof(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid", allow_inf_nan=False)
    previewId: str = Field(..., max_length=200, min_length=1)
    qcRevision: int = Field(..., ge=1)
    canonicalChecksum: str = Field(..., pattern="^[a-f0-9]{64}$")
    parametersChecksum: str = Field(..., pattern="^[a-f0-9]{64}$")
    selectionArtifactId: str = Field(..., max_length=200, min_length=1)
    selectionChecksum: str = Field(..., pattern="^[a-f0-9]{64}$")
    includedCount: int = Field(..., ge=1)
    excludedCount: int = Field(..., ge=0)


class QcJobResult(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid", allow_inf_nan=False)
    analysisRunId: str = Field(..., max_length=200, min_length=1)
    stepId: str = Field(..., max_length=200, min_length=1)
    submissionId: str = Field(..., max_length=200, min_length=1)
    operation: Literal["QC", "PREVIEW", "FILTER"] = Field(...)
    artifacts: list[QcProducedArtifact] = Field(..., max_length=2)
    summary: QcSummary | None = Field(...)
    preview: QcPreviewProof | None = Field(...)


class QcDecision(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid", allow_inf_nan=False)
    schemaVersion: Literal["1.0.0"] = Field(...)
    id: str = Field(..., max_length=200, min_length=1)
    organizationId: str = Field(..., max_length=200, min_length=1)
    projectId: str = Field(..., max_length=200, min_length=1)
    analysisRunId: str = Field(..., max_length=200, min_length=1)
    datasetVersionId: str = Field(..., max_length=200, min_length=1)
    canonicalChecksum: str = Field(..., pattern="^[a-f0-9]{64}$")
    qcRevision: int = Field(..., ge=1)
    preview: QcPreviewProof = Field(...)
    selection: QcSelectionParameters = Field(...)
    actorId: str = Field(..., max_length=200, min_length=1)
    createdAt: str = Field(...)
    reason: str = Field(..., max_length=1000, min_length=1)
    geneSetPolicy: Literal["cellweave-symbol-prefixes-v1"] = Field(...)
    scrubletProfile: Literal["cellweave-scanpy-scrublet-v1"] = Field(...)


class QcApprovalSignal(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid", allow_inf_nan=False)
    schemaVersion: Literal["1.0.0"] = Field(...)
    analysisRunId: str = Field(..., max_length=200, min_length=1)
    decisionId: str = Field(..., max_length=200, min_length=1)


class QcStepContext(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid", allow_inf_nan=False)
    operation: Literal["QC", "PREVIEW", "FILTER"] = Field(...)
    revision: int = Field(..., ge=1)
    selection: QcSelectionParameters | None = Field(...)
    decisionId: Annotated[str, Field(max_length=200, min_length=1)] | None = Field(...)
    outputIds: list[str] = Field(..., max_length=2)
    deadlineAt: str | None = Field(...)


class QcStepControl(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid", allow_inf_nan=False)
    stepId: str = Field(..., max_length=200, min_length=1)
    submissionId: str = Field(..., max_length=200, min_length=1)
    status: WorkflowStepState = Field(...)
    providerJobId: Annotated[str, Field(max_length=200, min_length=1)] | None = Field(...)
    providerState: Literal["UNKNOWN", "PENDING", "RUNNING", "COMPLETED", "FAILED", "CANCELLED", "TIMEOUT"] = Field(...)
    context: QcStepContext = Field(...)
    result: QcJobResult | None = Field(...)


class QcControl(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid", allow_inf_nan=False)
    analysisRunId: str = Field(..., max_length=200, min_length=1)
    status: RunState = Field(...)
    projectionVersion: int = Field(..., ge=0)
    cancelRequested: bool = Field(...)
    filterCommitted: bool = Field(...)
    qcRevision: int = Field(..., ge=1)
    steps: list[QcStepControl] = Field(..., max_length=1000)
    decision: QcDecision | None = Field(...)
    approvalPending: bool = Field(...)


class QcProjection(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid", allow_inf_nan=False)
    analysisRunId: str = Field(..., max_length=200, min_length=1)
    sequence: int = Field(..., ge=1)
    status: RunState = Field(...)


class QcCellMetrics(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid", allow_inf_nan=False)
    cellId: str = Field(...)
    sampleId: str | None = Field(...)
    sampleKey: str | None = Field(...)
    captureGroupKey: str | None = Field(...)
    total_counts: float = Field(...)
    n_genes_by_counts: int = Field(..., ge=0)
    total_counts_mt: float | None = Field(...)
    pct_counts_mt: float | None = Field(...)
    total_counts_ribo: float | None = Field(...)
    pct_counts_ribo: float | None = Field(...)
    doublet_score: float | None = Field(...)
    predicted_doublet: bool | None = Field(...)


class QcSelectionHeader(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid", allow_inf_nan=False)
    schemaVersion: Literal["1.0.0"] = Field(...)
    previewId: str = Field(...)
    qcRevision: int = Field(..., ge=0)
    canonicalChecksum: str = Field(..., pattern="^[a-f0-9]{64}$")
    parametersChecksum: str = Field(..., pattern="^[a-f0-9]{64}$")
    cellOrderChecksum: str = Field(..., pattern="^[a-f0-9]{64}$")
    includedCount: int = Field(..., ge=0)
    excludedCount: int = Field(..., ge=0)


class QcSelectionRow(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid", allow_inf_nan=False)
    cellId: str = Field(...)
    included: bool = Field(...)


class QcReviewView(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid", allow_inf_nan=False)
    analysisRunId: str = Field(...)
    datasetVersionId: str = Field(...)
    status: RunState = Field(...)
    qcRevision: int = Field(..., ge=1)
    summary: QcSummary | None = Field(...)
    preview: QcPreviewProof | None = Field(...)
    previewPending: bool = Field(...)
    previewError: Literal["QC_SELECTION_REJECTED"] | None = Field(...)
    previewParameters: QcSelectionParameters | None = Field(...)
    decision: QcDecision | None = Field(...)
    canApprove: bool = Field(...)
    filteredArtifactId: str | None = Field(...)


class QcSampleOption(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid", allow_inf_nan=False)
    sampleId: str = Field(...)
    sampleKey: str = Field(...)
    label: str = Field(...)


class QcDatasetOption(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid", allow_inf_nan=False)
    datasetVersionId: str = Field(...)
    label: str = Field(...)
    samples: list[QcSampleOption] = Field(..., max_length=1000)


class QcInputOptions(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid", allow_inf_nan=False)
    canStart: bool = Field(...)
    datasets: list[QcDatasetOption] = Field(..., max_length=100)



ExecutionCeilings.model_rebuild()
ExecutionEnvelope.model_rebuild()
ExecutionSourceCapability.model_rebuild()
PreparedExecution.model_rebuild()
ExecutionResult.model_rebuild()
ExecutionProjection.model_rebuild()
ExecutionControl.model_rebuild()
ComputeCancellationResponse.model_rebuild()
ExecutionUsage.model_rebuild()
QcIssue.model_rebuild()
QcSampleBinding.model_rebuild()
QcAnalysisParameters.model_rebuild()
QcCaptureRequest.model_rebuild()
QcStartRequest.model_rebuild()
QcThresholdRule.model_rebuild()
QcSelectionParameters.model_rebuild()
QcApprovalRequest.model_rebuild()
QcHistogramBin.model_rebuild()
QcMetricSummary.model_rebuild()
QcSampleSummary.model_rebuild()
QcSoftwareVersion.model_rebuild()
QcParameterValue.model_rebuild()
QcDoubletAssessment.model_rebuild()
QcSummary.model_rebuild()
QcArtifactTarget.model_rebuild()
QcArtifactInput.model_rebuild()
QcFilterBinding.model_rebuild()
QcPreparedExecution.model_rebuild()
QcProducedArtifact.model_rebuild()
QcPreviewProof.model_rebuild()
QcJobResult.model_rebuild()
QcDecision.model_rebuild()
QcApprovalSignal.model_rebuild()
QcStepContext.model_rebuild()
QcStepControl.model_rebuild()
QcControl.model_rebuild()
QcProjection.model_rebuild()
QcCellMetrics.model_rebuild()
QcSelectionHeader.model_rebuild()
QcSelectionRow.model_rebuild()
QcReviewView.model_rebuild()
QcSampleOption.model_rebuild()
QcDatasetOption.model_rebuild()
QcInputOptions.model_rebuild()

ComputeJobSubmitRequest.model_rebuild()

ComputeJobResultResponse.model_rebuild()
